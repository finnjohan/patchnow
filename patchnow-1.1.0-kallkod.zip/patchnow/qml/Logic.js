.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

// Ren logik utan QML-beroenden: adresser, tolkning av flödena och
// bedömningen av vad som är kritiskt. Testas med node (tests/logic.test.js).

var KEV_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
var KEV_MIRROR_URL = "https://raw.githubusercontent.com/cisagov/kev-data/main/known_exploited_vulnerabilities.json"
var NVD_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
var EPSS_URL = "https://api.first.org/data/v1/epss"
var CERTSE_URL = "https://www.cert.se/feed.xml"

var DAY = 86400000
var RECENT_DAYS = 10        // nya CVE:er utanför KEV som bedöms med CVSS + EPSS
var EPSS_BATCH = 50         // FIRST tar högst 2000 tecken i cve-parametern

// ---- Adresser ---------------------------------------------------------------

function pad(n) { return (n < 10 ? "0" : "") + n }

// NVD vill ha ISO 8601 utan tidszon (tolkas som UTC).
function nvdDate(ms) {
    var d = new Date(ms)
    return d.getUTCFullYear() + "-" + pad(d.getUTCMonth() + 1) + "-" + pad(d.getUTCDate()) +
           "T" + pad(d.getUTCHours()) + ":" + pad(d.getUTCMinutes()) + ":" + pad(d.getUTCSeconds()) + ".000"
}

// CVE:er som lagts till i KEV de senaste `days` dagarna (NVD tillåter högst 90).
function nvdKevUrl(nowMs, days) {
    days = Math.min(90, Math.max(1, days))
    return NVD_URL + "?kevStartDate=" + nvdDate(nowMs - days * DAY) + "&kevEndDate=" + nvdDate(nowMs)
}

// Nya CVE:er med CVSS 3 = CRITICAL, publicerade de senaste `days` dagarna.
function nvdRecentUrl(nowMs, days) {
    return NVD_URL + "?cvssV3Severity=CRITICAL&noRejected&pubStartDate=" + nvdDate(nowMs - days * DAY) +
           "&pubEndDate=" + nvdDate(nowMs)
}

// Ändringar sedan förra hämtningen (NVD tillåter högst 120 dagar).
function nvdKevChangesUrl(fromMs, nowMs) {
    return NVD_URL + "?hasKev&lastModStartDate=" + nvdDate(fromMs) + "&lastModEndDate=" + nvdDate(nowMs)
}

function nvdRecentChangesUrl(fromMs, nowMs) {
    return NVD_URL + "?cvssV3Severity=CRITICAL&noRejected&lastModStartDate=" + nvdDate(fromMs) +
           "&lastModEndDate=" + nvdDate(nowMs)
}

// Lägger in nya NVD-poster i en tidigare tabell och tar bort det som är för gammalt.
function mergeNvd(old, fresh, keepSinceMs) {
    var out = {}
    function keep(id, n) {
        var t = n.kevAdded ? parseDay(n.kevAdded) : Date.parse(n.published)
        if (!keepSinceMs || isNaN(t) || t >= keepSinceMs) out[id] = n
    }
    for (var a in (old || {})) keep(a, old[a])
    for (var b in (fresh || {})) keep(b, fresh[b])
    return out
}

function epssUrls(ids) {
    var out = []
    for (var i = 0; i < ids.length; i += EPSS_BATCH)
        out.push(EPSS_URL + "?cve=" + ids.slice(i, i + EPSS_BATCH).join(","))
    return out
}

function nvdLink(id) { return "https://nvd.nist.gov/vuln/detail/" + id }
function kevLink(id) { return "https://www.cisa.gov/known-exploited-vulnerabilities-catalog?search_api_fulltext=" + id }

// ---- Datum ------------------------------------------------------------------

function dayKey(ms) {
    var d = new Date(ms)
    return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate())
}

// "2026-11-18" som lokal midnatt.
function parseDay(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || "")
    return m ? new Date(+m[1], +m[2] - 1, +m[3]).getTime() : 0
}

function daysBetween(fromMs, toMs) {
    return Math.round((parseDay(dayKey(toMs)) - parseDay(dayKey(fromMs))) / DAY)
}

function ageMinutes(thenMs, nowMs) { return (nowMs - thenMs) / 60000 }

function formatClock(ms) {
    var d = new Date(ms)
    return pad(d.getHours()) + ":" + pad(d.getMinutes())
}

var MONTHS = {
    en: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    sv: ["jan", "feb", "mar", "apr", "maj", "jun", "jul", "aug", "sep", "okt", "nov", "dec"]
}

function formatDay(ms, lang) {
    if (!ms) return ""
    var d = new Date(ms), m = (MONTHS[lang] || MONTHS.en)[d.getMonth()]
    return lang === "sv" ? d.getDate() + " " + m : m + " " + d.getDate()
}

// ---- Tolkning ---------------------------------------------------------------

// CISA KEV: bara poster tillagda från och med `sinceDay` ("YYYY-MM-DD").
function parseKev(text, sinceDay) {
    var d = JSON.parse(text)
    if (!d || !d.vulnerabilities) throw new Error("not KEV")
    var out = []
    for (var i = 0; i < d.vulnerabilities.length; i++) {
        var v = d.vulnerabilities[i]
        if (!v.cveID || (sinceDay && v.dateAdded < sinceDay)) continue
        out.push({ id: v.cveID, vendor: v.vendorProject || "", product: v.product || "",
                   name: v.vulnerabilityName || "", desc: v.shortDescription || "",
                   added: v.dateAdded || "", due: v.dueDate || "",
                   ransomware: v.knownRansomwareCampaignUse === "Known",
                   action: v.requiredAction || "" })
    }
    return { version: d.catalogVersion || "", list: out }
}

// Högsta poäng av en viss metrik. NVD:s egen (Primary) går före leverantörens (Secondary).
function bestMetric(list) {
    if (!list || list.length === 0) return null
    var primary = list.filter(function (m) { return m.type === "Primary" })
    var pool = primary.length > 0 ? primary : list
    var best = null
    for (var i = 0; i < pool.length; i++) {
        var c = pool[i].cvssData
        if (c && typeof c.baseScore === "number" && (!best || c.baseScore > best.score))
            best = { score: c.baseScore, vector: c.vectorString || "", version: c.version || "" }
    }
    return best
}

// NVD API 2.0: tabell id -> { cvss, vector, version, desc, published, ssvc, kevAdded }
function parseNvd(text) {
    var d = JSON.parse(text)
    if (!d || !d.vulnerabilities) throw new Error("not NVD")
    var out = {}
    for (var i = 0; i < d.vulnerabilities.length; i++) {
        var c = d.vulnerabilities[i].cve
        if (!c || !c.id) continue
        var m = c.metrics || {}
        var best = bestMetric(m.cvssMetricV31) || bestMetric(m.cvssMetricV30) || bestMetric(m.cvssMetricV40)
        var ssvc = {}
        var sl = m.ssvcV203 || m.ssvcV2 || []
        for (var j = 0; j < sl.length; j++) {
            var opts = (sl[j].ssvcData && sl[j].ssvcData.options) || []
            for (var k = 0; k < opts.length; k++)
                for (var key in opts[k]) ssvc[key] = String(opts[k][key]).toLowerCase()
        }
        var cpes = [], seenCpe = {}
        var confs = c.configurations || []
        for (var ci = 0; ci < confs.length; ci++) {
            var nodes = confs[ci].nodes || []
            for (var ni = 0; ni < nodes.length; ni++) {
                var ms = nodes[ni].cpeMatch || []
                for (var mi = 0; mi < ms.length; mi++) {
                    if (!ms[mi].vulnerable || !ms[mi].criteria) continue
                    var parts = ms[mi].criteria.split(":")
                    var key3 = parts[2] + ":" + parts[3] + ":" + parts[4]
                    if (!seenCpe[key3] && cpes.length < 60) { seenCpe[key3] = true; cpes.push(key3) }
                }
            }
        }
        var desc = ""
        var ds = c.descriptions || []
        for (var n = 0; n < ds.length; n++) if (ds[n].lang === "en") { desc = ds[n].value; break }
        out[c.id] = { cvss: best ? best.score : -1, vector: best ? best.vector : "", version: best ? best.version : "",
                      desc: desc, published: c.published || "", ssvc: ssvc, cpes: cpes,
                      kevAdded: c.cisaExploitAdd || "", kevDue: c.cisaActionDue || "",
                      kevName: c.cisaVulnerabilityName || "", kevAction: c.cisaRequiredAction || "" }
    }
    return out
}

// FIRST EPSS: tabell id -> { epss, pct } (värdena kommer som strängar)
function parseEpss(text) {
    var d = JSON.parse(text)
    if (!d || !d.data) throw new Error("not EPSS")
    var out = {}
    for (var i = 0; i < d.data.length; i++) {
        var r = d.data[i]
        out[r.cve] = { epss: parseFloat(r.epss), pct: parseFloat(r.percentile) }
    }
    return out
}

function decodeEntities(s) {
    return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
            .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, "\"")
            .replace(/&#39;|&apos;/g, "'").replace(/&#(\d+);/g, function (m, n) { return String.fromCharCode(+n) })
            .replace(/&amp;/g, "&")
}

function stripTags(s) { return s.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim() }

function tagText(block, tag) {
    var m = new RegExp("<" + tag + "(\\s[^>]*)?>([\\s\\S]*?)</" + tag + ">", "i").exec(block)
    return m ? decodeEntities(m[2]).trim() : ""
}

function findCves(s) {
    var seen = {}, out = []
    var re = /CVE-\d{4}-\d{4,7}/g, m
    while ((m = re.exec(s)) !== null) if (!seen[m[0]]) { seen[m[0]] = true; out.push(m[0]) }
    return out
}

// CERT-SE skriver "Kritisk sårbarhet i …" eller "Kritiska sårbarheter i …" när det är bråttom.
function isCriticalTitle(t) {
    return /^\s*(kritisk|kritiska|critical)\b/i.test(t) || /allvarlig(a)? sårbarhet(er)? .*utnyttja/i.test(t)
}

// Atom (CERT-SE använder Atom) eller RSS 2.0. Ingen DOM i QML, så det blir reguljära uttryck.
function parseFeed(text) {
    var out = []
    var re = /<(entry|item)[\s>][\s\S]*?<\/\1>/gi, m
    while ((m = re.exec(text)) !== null) {
        var b = m[0]
        var title = stripTags(tagText(b, "title"))
        var link = ""
        var lm = /<link[^>]*href="([^"]+)"/i.exec(b)
        if (lm) link = decodeEntities(lm[1])
        else link = tagText(b, "link")
        var date = tagText(b, "published") || tagText(b, "updated") || tagText(b, "pubDate")
        var body = tagText(b, "content") || tagText(b, "summary") || tagText(b, "description")
        var t = Date.parse(date)
        out.push({ title: title, link: link, published: isNaN(t) ? 0 : t,
                   cves: findCves(title + " " + body), critical: isCriticalTitle(title),
                   summary: stripTags(body).substring(0, 400) })
    }
    return out
}

// ---- Plattform --------------------------------------------------------------
// Vad en sårbarhet drabbar: windows, linux, virt (hypervisorer), apps (serverprogram
// på Windows/Linux), device (nätverksutrustning och andra apparater) eller client
// (datorer och mobiler: Apple, Android, webbläsare, Office).

var PLATFORMS = ["windows", "linux", "apps", "virt", "device", "client"]
var DEFAULT_PLATFORMS = { windows: true, linux: true, apps: true, virt: true, device: false, client: false }

var CPE_WINDOWS = /^(o:microsoft:windows|a:microsoft:(exchange|sharepoint|sql_server|outlook_web|internet_information|iis|windows_server|system_center|active_directory|hyper-v|dynamics))/
var CPE_KERNEL = /^o:linux:linux_kernel/
// Linuxdistributioner listas när ett paket i dem är sårbart. De avgör inte ensamma.
var CPE_DISTRO = /^o:(redhat:|debian:|canonical:|suse:|opensuse:|fedoraproject:|oracle:linux|almalinux:|rockylinux:|alpinelinux:|centos:)/
var CPE_VIRT = /^(o:vmware:esxi|a:vmware:(vcenter|esxi|vsphere)|o:citrix:hypervisor|o:xen:|a:xen:|o:proxmox:|a:proxmox:)/
var CPE_CLIENT = /^(a:apple:|o:apple:|o:google:android|a:google:(chrome|android)|a:mozilla:|a:microsoft:(office|365_apps|word|excel|powerpoint|outlook$|edge|teams|visio|project)|a:webkitgtk:|a:wpewebkit:|o:samsung:)/
var CPE_APPLIANCE = /^a:(cisco|fortinet|paloaltonetworks|sonicwall|f5|checkpoint|juniper|zyxel|mikrotik|barracuda|arista|synology|qnap|ubiquiti|draytek|watchguard|hikvision|dahua|tp-link|dlink|netgear|array_networks|progress:loadmaster|kemp|ivanti:(connect_secure|policy_secure|pulse|neurons_for_zero_trust)|citrix:(netscaler|adc|gateway|application_delivery)|beyondtrust:(remote_support|privileged_remote_access)|sophos:(firewall|xg))/
var OS_VENDORS = /^o:(microsoft|linux|redhat|debian|canonical|suse|opensuse|fedoraproject|oracle|almalinux|rockylinux|alpinelinux|centos|vmware|citrix|xen|proxmox|freebsd|openbsd|netbsd)/

var TXT_CLIENT = /\b(apple|ios|ipados|macos|safari|webkit|android|pixel|chrome|chromium|samsung mobile|qualcomm|mali gpu|firefox|thunderbird)\b|microsoft (office|word|excel|outlook|powerpoint|edge|teams)/
var TXT_DEVICE = /\b(cisco|fortinet|forti\w+|palo alto|pan-os|netscaler|citrix adc|citrix gateway|connect secure|policy secure|pulse secure|sonicwall|sonicos|barracuda|big-ip|f5|check point|mikrotik|routeros|zyxel|juniper|junos|arista|velocloud|tp-link|d-link|netgear|synology|qnap|hikvision|dahua|ubiquiti|draytek|watchguard|loadmaster|aruba|ruckus|tenda|totolink|digiever|router|routers|nas|camera|nvr|dvr|printer|firmware)\b/
var TXT_WINDOWS = /\b(windows|exchange server|sharepoint|sql server|iis|active directory|hyper-v|win32k|ntlm|smb)\b|microsoft/
var TXT_LINUX = /\b(linux|kernel|red hat|rhel|debian|ubuntu|suse|glibc|sudo|systemd|polkit|openssh|xz utils)\b/
var TXT_VIRT = /\b(esxi|vcenter|vsphere|proxmox|xenserver|citrix hypervisor)\b/

function platformOf(it) {
    var cpes = it.cpes || []
    var i
    if (cpes.length > 0) {
        for (i = 0; i < cpes.length; i++) if (CPE_WINDOWS.test(cpes[i])) return "windows"
        for (i = 0; i < cpes.length; i++) if (CPE_KERNEL.test(cpes[i])) return "linux"
        for (i = 0; i < cpes.length; i++) if (CPE_VIRT.test(cpes[i])) return "virt"
        var nClient = 0, nDevice = 0, nApp = 0, nDistro = 0
        for (i = 0; i < cpes.length; i++) {
            var c = cpes[i]
            if (CPE_DISTRO.test(c)) nDistro++
            else if (c.indexOf("h:") === 0 || CPE_APPLIANCE.test(c) || (c.indexOf("o:") === 0 && !OS_VENDORS.test(c) && !CPE_CLIENT.test(c))) nDevice++
            else if (CPE_CLIENT.test(c)) nClient++
            else nApp++
        }
        // Serverprogram vinner (t.ex. ett bibliotek som också finns i en apparat)
        if (nApp > 0) return "apps"
        if (nDevice > 0) return "device"
        if (nClient > 0) return "client"
        if (nDistro > 0) return "linux"
    }
    var text = ((it.vendor || "") + " " + (it.product || "") + " " + (it.name || "")).toLowerCase()
    if (TXT_VIRT.test(text)) return "virt"
    if (TXT_DEVICE.test(text)) return "device"
    if (TXT_CLIENT.test(text)) return "client"
    if (TXT_WINDOWS.test(text)) return "windows"
    if (TXT_LINUX.test(text)) return "linux"
    return "apps"
}

// ---- Bedömning --------------------------------------------------------------

// Nåbar över nätet utan inloggning och utan att någon behöver klicka.
function remoteNoAuth(vector) {
    return /AV:N/.test(vector) && /PR:N/.test(vector) && /UI:N/.test(vector)
}

// Reserv när NVD inte har satt någon poäng än.
function looksLikeUnauthRce(desc) {
    return /unauthenticated|without authentication|unauthorized remote|authentication bypass/i.test(desc) &&
           /arbitrary code|arbitrary commands|remote code execution|code execution|command injection|execute (os |system )?commands/i.test(desc)
}

var LEVELS = {
    strict: { cvss: 9.0, epss: 0.7 },
    normal: { cvss: 9.0, epss: 0.4 },
    broad:  { cvss: 8.0, epss: 0.2 }
}

// Slår ihop källorna till en lista av poster.
// kev: parseKev().list, nvd: tabell (KEV + nya), epss: tabell, feed: parseFeed()
function merge(kev, nvd, epss, feed, recentSinceMs, feedSinceMs) {
    nvd = nvd || {}; epss = epss || {}; feed = feed || []
    var byId = {}, list = []

    function add(id, base) {
        var n = nvd[id] || {}
        var e = epss[id] || null
        var it = {
            kind: "cve", id: id,
            vendor: base.vendor || "", product: base.product || "", name: base.name || n.kevName || "",
            desc: n.desc || base.desc || "",
            kev: base.kev || null,
            cvss: typeof n.cvss === "number" ? n.cvss : -1, vector: n.vector || "", cvssVersion: n.version || "",
            ssvc: n.ssvc || {}, cpes: n.cpes || [], epss: e ? e.epss : -1, pct: e ? e.pct : -1,
            published: n.published || "", certse: [], link: nvdLink(id), date: 0
        }
        byId[id] = it
        list.push(it)
        return it
    }

    for (var i = 0; i < (kev || []).length; i++) {
        var k = kev[i]
        if (byId[k.id]) continue
        var it = add(k.id, { vendor: k.vendor, product: k.product, name: k.name, desc: k.desc,
                             kev: { added: k.added, due: k.due, ransomware: k.ransomware, action: k.action } })
        it.date = parseDay(k.added)
    }
    // NVD kan ha KEV-poster som CISA:s fil inte hunnit få (eller tvärtom)
    for (var id in nvd) {
        var n = nvd[id]
        if (byId[id]) continue
        if (n.kevAdded) {
            var it2 = add(id, { kev: { added: n.kevAdded, due: n.kevDue, ransomware: false, action: n.kevAction } })
            it2.date = parseDay(n.kevAdded)
        } else {
            var pub = Date.parse(n.published)
            if (!isNaN(pub) && recentSinceMs && pub < recentSinceMs) continue
            var it3 = add(id, {})
            it3.date = isNaN(pub) ? 0 : pub
        }
    }
    for (var f = 0; f < feed.length; f++) {
        var a = feed[f], linked = false
        if (feedSinceMs && a.published && a.published < feedSinceMs) continue
        for (var c = 0; c < a.cves.length; c++) {
            var hit = byId[a.cves[c]]
            if (hit) { hit.certse.push({ title: a.title, link: a.link, critical: a.critical }); linked = true }
        }
        if (a.critical && !linked) {
            list.push({ kind: "certse", id: a.link, vendor: "CERT-SE", product: "", name: a.title,
                        desc: a.summary, kev: null, cvss: -1, vector: "", cvssVersion: "", ssvc: {}, cpes: [],
                        epss: -1, pct: -1, published: "", certse: [{ title: a.title, link: a.link, critical: true }],
                        cves: a.cves, link: a.link, date: a.published })
        }
    }
    return list
}

// tier 2 = kritiskt (åtgärda nu), 1 = bevaka, 0 = visas inte. reasons = nycklar för I18n.
function evaluate(it, level) {
    var L = LEVELS[level] || LEVELS.normal
    var r = []
    var net = remoteNoAuth(it.vector)
    var scored = it.cvss >= 0
    var auto = it.ssvc.automatable === "yes" && it.ssvc.technicalImpact === "total"
    var rceText = looksLikeUnauthRce(it.desc)
    var certCrit = it.certse.some(function (a) { return a.critical })
    var tier = 0

    if (it.kind === "certse") {
        r.push("certse")
        return { tier: level === "strict" ? 1 : 2, reasons: r }
    }

    if (it.kev) r.push("kev")
    if (scored) r.push("cvss")
    else r.push("unscored")
    if (net) r.push("net")
    if (auto) r.push("ssvc")
    if (!scored && rceText) r.push("rcetext")
    if (it.kev && it.kev.ransomware) r.push("ransomware")
    if (it.epss >= L.epss) r.push("epss")
    if (it.certse.length > 0) r.push(certCrit ? "certsecrit" : "certse")

    if (it.kev) {
        tier = 1
        if (scored) {
            if (level === "strict") {
                if (it.cvss >= L.cvss && net && it.ssvc.automatable !== "no") tier = 2
            } else if (level === "normal") {
                if (it.cvss >= L.cvss && net) tier = 2
                else if ((it.kev.ransomware || certCrit) && it.cvss >= 8.0) tier = 2
            } else {
                if (it.cvss >= L.cvss || (net && it.cvss >= 7.0) || it.kev.ransomware) tier = 2
            }
        } else {
            if (level === "strict") { if (auto && rceText) tier = 2 }
            else if (auto || rceText || (level === "broad" && it.kev.ransomware)) tier = 2
        }
    } else {
        var bad = scored && it.cvss >= 9.0 && net
        if (bad && it.epss >= L.epss) tier = 2
        else if (bad && certCrit && level !== "strict") tier = 2
        else if (bad && (it.epss >= 0.1 || it.certse.length > 0)) tier = 1
        else if (it.certse.length > 0 && scored && it.cvss >= 9.0) tier = 1
    }
    return { tier: tier, reasons: r }
}

// Bedömer, filtrerar bort tystade leverantörer och plattformar som inte bevakas,
// och sorterar: kritiska först, nyast först.
// muted: lista med leverantörsnamn (gemener), handled: tabell id -> true,
// platforms: tabell plattform -> true/false (saknas = DEFAULT_PLATFORMS)
// Returnerar { items, hidden } där hidden räknar kritiska poster som plattformsfiltret tog bort.
function assess(list, level, muted, handled, platforms) {
    var out = [], hidden = 0
    muted = muted || []; handled = handled || {}; platforms = platforms || DEFAULT_PLATFORMS
    for (var i = 0; i < list.length; i++) {
        var it = list[i]
        var ev = evaluate(it, level)
        if (ev.tier === 0) continue
        if (it.kind === "cve" && muted.indexOf(it.vendor.toLowerCase()) >= 0) continue
        it.platform = platformOf(it)
        if (platforms[it.platform] === false || (platforms[it.platform] === undefined && !DEFAULT_PLATFORMS[it.platform])) {
            if (ev.tier === 2) hidden++
            continue
        }
        it.tier = ev.tier
        it.reasons = ev.reasons
        it.handled = !!handled[it.id]
        out.push(it)
    }
    out.sort(function (a, b) {
        if (a.handled !== b.handled) return a.handled ? 1 : -1
        if (a.tier !== b.tier) return b.tier - a.tier
        return b.date - a.date
    })
    return { items: out, hidden: hidden }
}

// Vilka id:n behöver EPSS: allt i KEV och nya CVE:er som annars kunde vara kritiska.
function epssCandidates(kev, nvd) {
    var ids = [], seen = {}
    for (var i = 0; i < (kev || []).length; i++) if (!seen[kev[i].id]) { seen[kev[i].id] = true; ids.push(kev[i].id) }
    for (var id in (nvd || {})) {
        var n = nvd[id]
        if (seen[id]) continue
        if (n.kevAdded || (n.cvss >= 8.0 && remoteNoAuth(n.vector))) { seen[id] = true; ids.push(id) }
    }
    return ids
}

// ---- Larm -------------------------------------------------------------------

// Tyst tid: larm under natten flyttas till morgonen (lokal tid).
function alarmTime(nowMs, quiet, fromHour, toHour) {
    var t = nowMs + 60000
    if (!quiet) return t
    var d = new Date(t), h = d.getHours() + d.getMinutes() / 60
    var inQuiet = fromHour > toHour ? (h >= fromHour || h < toHour) : (h >= fromHour && h < toHour)
    if (!inQuiet) return t
    var m = new Date(d.getFullYear(), d.getMonth(), d.getDate(), toHour, 0, 0, 0)
    if (m.getTime() <= t) m = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1, toHour, 0, 0, 0)
    return m.getTime()
}

function title(it) {
    if (it.kind === "certse") return it.name
    var v = it.vendor || "", p = it.product || ""
    if (v === "" && p === "") return it.name ? it.name.replace(/ Vulnerability$/, "") : it.id
    if (p === "" || p.toLowerCase() === v.toLowerCase()) return v || p
    // "Barracuda Networks" + "Barracuda Email Security Gateway" -> bara produkten
    var first = v.split(" ")[0].toLowerCase()
    if (first !== "" && p.toLowerCase().indexOf(first) === 0) return p
    return v + " " + p
}

function alarmMessage(newItems) {
    if (newItems.length === 1) {
        var it = newItems[0]
        return "PatchNow: " + (it.kind === "certse" ? "CERT-SE – " + it.name : it.id + " – " + title(it))
    }
    return "PatchNow: " + newItems.length + " × " + newItems.slice(0, 3).map(title).join(", ")
}
