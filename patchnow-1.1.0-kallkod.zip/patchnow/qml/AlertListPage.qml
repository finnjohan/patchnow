// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Logic.js" as Logic

Page {
    id: page

    header: PageHeader {
        id: header
        title: "PatchNow"
        trailingActionBar.actions: [
            Action {
                iconName: "settings"
                text: root.tr("Settings")
                onTriggered: stack.push(Qt.resolvedUrl("SettingsPage.qml"))
            },
            Action {
                iconName: "reload"
                text: root.tr("Refresh")
                enabled: !root.loading && !root.demo
                onTriggered: root.refresh(true)
            }
        ]
    }

    function chipsFor(m) {
        var out = []
        if (m.kind === "certse") out.push({ text: "CERT-SE", strong: true })
        if (m.platform === "windows" || m.platform === "linux" || m.platform === "virt")
            out.push({ text: root.tr("platform:" + m.platform), strong: false })
        if (m.cvss >= 0) out.push({ text: "CVSS " + m.cvss.toFixed(1), strong: m.cvss >= 9 })
        if (m.inKev) out.push({ text: root.tr("Exploited"), strong: true })
        if (m.ransomware) out.push({ text: root.tr("Ransomware"), strong: true })
        if (m.epss >= 0.1) out.push({ text: "EPSS " + Math.round(m.epss * 100) + " %", strong: m.epss >= 0.4 })
        if (m.certse && m.kind !== "certse") out.push({ text: "CERT-SE", strong: false })
        return out
    }

    readonly property string statusError: {
        var e = root.errors
        var names = { kev: "CISA", nvd: "NVD", epss: "EPSS", certse: "CERT-SE" }
        var failed = [], limited = false
        for (var k in names) if (e[k]) { failed.push(names[k]); if (e[k] === "limit") limited = true }
        if (failed.length === 0) return ""
        if (failed.length === 4 && !limited)
            return root.tr("No connection. Showing what was saved %1.").arg(Logic.formatClock(root.fetchedAt))
        if (limited) return root.tr("%1 is busy right now (rate limit). Trying again later.").arg(failed.join(", "))
        return root.tr("Could not reach %1. The assessment may be incomplete.").arg(failed.join(", "))
    }

    ListView {
        id: list
        anchors { top: header.bottom; left: parent.left; right: parent.right; bottom: parent.bottom }
        clip: true
        model: root.alerts
        // PullToRefresh och nya data flyttar innehållet; börja överst tills man själv scrollar
        property bool userScrolled: false
        onMovementStarted: userScrolled = true
        Timer { id: toTop; interval: 300; running: true; onTriggered: if (!list.userScrolled) list.positionViewAtBeginning() }
        Connections {
            target: root
            function onItemsChanged() { toTop.restart() }
            function onLoadingChanged() { toTop.restart() }
        }

        PullToRefresh {
            parent: list
            refreshing: root.loading
            enabled: !root.demo
            onRefresh: root.refresh(true)
        }

        header: Item {
            width: list.width
            height: summary.height + units.gu(3)

            Rectangle {
                id: summary
                anchors { left: parent.left; right: parent.right; top: parent.top; margins: units.gu(1.5) }
                height: summaryCol.height + units.gu(3)
                radius: units.gu(1)
                color: root.criticalCount > 0 ? Qt.rgba(root.criticalColor.r, root.criticalColor.g, root.criticalColor.b, 0.12)
                                              : theme.palette.normal.foreground

                Icon {
                    id: bigIcon
                    anchors { left: parent.left; leftMargin: units.gu(2); top: parent.top; topMargin: units.gu(1.6) }
                    width: units.gu(4); height: width
                    name: root.criticalCount > 0 ? "security-alert" : "ok"
                    color: root.criticalCount > 0 ? root.criticalColor : theme.palette.normal.positive
                }

                Column {
                    id: summaryCol
                    anchors { left: bigIcon.right; leftMargin: units.gu(1.5); right: parent.right; rightMargin: units.gu(2)
                              top: parent.top; topMargin: units.gu(1.5) }
                    spacing: units.gu(0.4)

                    Label {
                        width: parent.width
                        wrapMode: Text.WordWrap
                        textSize: Label.Large
                        font.weight: Font.Medium
                        text: {
                            if (root.fetchedAt === 0 && root.items.length === 0)
                                return root.loading ? root.tr("Checking…") : root.tr("No data yet")
                            if (root.criticalCount === 0) return root.tr("Nothing critical right now")
                            if (root.criticalCount === 1) return root.tr("1 vulnerability to act on now")
                            return root.tr("%1 vulnerabilities to act on now").arg(root.criticalCount)
                        }
                    }
                    Label {
                        width: parent.width
                        visible: root.newCount > 0
                        wrapMode: Text.WordWrap
                        color: root.criticalColor
                        font.weight: Font.Medium
                        text: root.newCount === 1 ? root.tr("1 new in the last 48 hours")
                                                  : root.tr("%1 new in the last 48 hours").arg(root.newCount)
                    }
                    Label {
                        width: parent.width
                        wrapMode: Text.WordWrap
                        textSize: Label.Small
                        color: theme.palette.normal.backgroundSecondaryText
                        text: (root.fetchedAt > 0 ? root.tr("Checked %1").arg(Logic.formatClock(root.fetchedAt)) + " · " : "") +
                              root.tr("Level: %1").arg(root.tr("level:" + root.level)) + " · " +
                              root.tr("last %1 days").arg(root.windowDays)
                    }
                    Label {
                        width: parent.width
                        visible: page.statusError !== ""
                        wrapMode: Text.WordWrap
                        textSize: Label.Small
                        color: root.watchColor
                        text: page.statusError
                    }
                }
            }
        }

        section.property: "group"
        section.delegate: Item {
            width: list.width
            height: units.gu(4.5)
            Label {
                anchors { left: parent.left; leftMargin: units.gu(2); bottom: parent.bottom; bottomMargin: units.gu(0.8) }
                text: section === "critical" ? root.tr("Act now") : section === "watch" ? root.tr("Keep an eye on") : root.tr("Handled")
                font.weight: Font.Medium
                color: section === "critical" ? root.criticalColor : theme.palette.normal.backgroundSecondaryText
            }
        }

        delegate: ListItem {
            id: li
            height: content.height + units.gu(2.4)
            divider.visible: true
            opacity: model.handled ? 0.6 : 1

            onClicked: stack.push(Qt.resolvedUrl("AlertPage.qml"), { itemId: model.itemId })

            leadingActions: ListItemActions {
                actions: [
                    Action {
                        iconName: model.handled ? "undo" : "ok"
                        text: model.handled ? root.tr("Not handled") : root.tr("Mark as handled")
                        onTriggered: { var id = model.itemId, on = !model.handled; Qt.callLater(function () { root.setHandled(id, on) }) }
                    }
                ]
            }
            trailingActions: ListItemActions {
                actions: [
                    Action {
                        iconName: "view-off"
                        text: root.tr("Hide this vendor")
                        visible: model.kind === "cve" && model.vendor !== ""
                        onTriggered: { var v = model.vendor; Qt.callLater(function () { root.muteVendor(v) }) }
                    }
                ]
            }

            Rectangle {
                anchors { left: parent.left; top: parent.top; bottom: parent.bottom; topMargin: units.gu(1); bottomMargin: units.gu(1) }
                width: units.dp(4)
                color: model.tier === 2 && !model.handled ? root.criticalColor : root.watchColor
                visible: !model.handled
            }

            Column {
                id: content
                anchors { left: parent.left; right: parent.right; leftMargin: units.gu(2); rightMargin: units.gu(2)
                          verticalCenter: parent.verticalCenter }
                spacing: units.gu(0.5)

                Item {
                    width: parent.width
                    height: headingLabel.height
                    Label {
                        id: headingLabel
                        anchors { left: parent.left; right: newBadge.visible ? newBadge.left : parent.right; rightMargin: units.gu(1) }
                        text: model.heading
                        font.weight: Font.Medium
                        elide: Text.ElideRight
                    }
                    Chip {
                        id: newBadge
                        anchors { right: parent.right; verticalCenter: headingLabel.verticalCenter }
                        visible: model.isNew
                        filled: true
                        tint: root.criticalColor
                        text: root.tr("NEW")
                    }
                }
                Label {
                    width: parent.width
                    textSize: Label.Small
                    color: theme.palette.normal.backgroundSecondaryText
                    elide: Text.ElideRight
                    text: [model.cve, Logic.formatDay(model.date, root.lang)].filter(function (s) { return s !== "" }).join(" · ")
                }
                Flow {
                    width: parent.width
                    spacing: units.gu(0.6)
                    Repeater {
                        model: page.chipsFor(li.itemModel)
                        Chip {
                            text: modelData.text
                            tint: modelData.strong ? (li.itemModel.tier === 2 ? root.criticalColor : root.watchColor)
                                                   : theme.palette.normal.backgroundSecondaryText
                        }
                    }
                }
            }
            readonly property var itemModel: ({ kind: model.kind, cvss: model.cvss, inKev: model.inKev,
                                                 ransomware: model.ransomware, epss: model.epss,
                                                 certse: model.certse, tier: model.tier, platform: model.platform })
        }

        footer: Item {
            width: list.width
            height: footerCol.height + units.gu(4)
            Column {
                id: footerCol
                anchors { left: parent.left; right: parent.right; top: parent.top; margins: units.gu(2) }
                spacing: units.gu(1.5)

                Label {
                    width: parent.width
                    visible: root.alerts.count === 0 && root.fetchedAt > 0
                    wrapMode: Text.WordWrap
                    horizontalAlignment: Text.AlignHCenter
                    color: theme.palette.normal.backgroundSecondaryText
                    text: root.tr("No actively exploited or critical vulnerabilities in this period.")
                }
                Label {
                    width: parent.width
                    visible: root.hiddenCount > 0
                    wrapMode: Text.WordWrap
                    horizontalAlignment: Text.AlignHCenter
                    textSize: Label.Small
                    color: theme.palette.normal.backgroundSecondaryText
                    text: (root.hiddenCount === 1 ? root.tr("1 critical vulnerability in platforms you don't watch is hidden.")
                                                  : root.tr("%1 critical vulnerabilities in platforms you don't watch are hidden.").arg(root.hiddenCount)) +
                          " " + root.tr("Change under Settings → Platforms.")
                }
                Button {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: root.handledCount > 0
                    text: root.showHandled ? root.tr("Hide handled") : root.tr("Show handled (%1)").arg(root.handledCount)
                    onClicked: root.setShowHandled(!root.showHandled)
                }
                Label {
                    width: parent.width
                    wrapMode: Text.WordWrap
                    horizontalAlignment: Text.AlignHCenter
                    textSize: Label.Small
                    color: theme.palette.normal.backgroundSecondaryText
                    text: root.tr("Swipe right to mark as handled, left to hide a vendor.")
                }
            }
        }
    }
}
