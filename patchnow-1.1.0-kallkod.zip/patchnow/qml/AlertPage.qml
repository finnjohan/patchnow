// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Logic.js" as Logic

Page {
    id: page
    property string itemId: ""
    readonly property var it: { root.items; return root.itemById(itemId) }
    readonly property bool critical: it !== null && it.tier === 2
    readonly property color tint: critical ? root.criticalColor : root.watchColor

    header: PageHeader {
        id: header
        title: page.it ? (page.it.kind === "cve" ? page.it.id : "CERT-SE") : ""
        trailingActionBar.actions: [
            Action {
                iconName: page.it && page.it.handled ? "undo" : "ok"
                text: page.it && page.it.handled ? root.tr("Not handled") : root.tr("Mark as handled")
                enabled: page.it !== null
                onTriggered: root.handleFromDetail(page.itemId, !page.it.handled)
            },
            Action {
                iconName: "external-link"
                text: root.tr("Open in browser")
                enabled: page.it !== null
                onTriggered: Qt.openUrlExternally(page.it.link)
            }
        ]
    }

    function reasonText(key) {
        var x = page.it
        switch (key) {
        case "kev": return root.tr("Actively exploited – in CISA's catalog of known exploited vulnerabilities since %1")
                          .arg(Logic.formatDay(Logic.parseDay(x.kev.added), root.lang))
        case "cvss": return root.tr("CVSS %1 of 10").arg(x.cvss.toFixed(1))
        case "unscored": return root.tr("No CVSS score from NVD yet")
        case "net": return root.tr("Can be attacked over the network without login or user interaction")
        case "ssvc": return root.tr("CISA: exploitation can be automated and gives full control")
        case "rcetext": return root.tr("The description says code can be run without logging in")
        case "ransomware": return root.tr("Used in ransomware campaigns")
        case "epss": return root.tr("EPSS %1 % – high probability of exploitation in the next 30 days").arg(Math.round(x.epss * 100))
        case "certsecrit": return root.tr("CERT-SE warns about it")
        case "certse": return x.kind === "certse" ? root.tr("CERT-SE has published a warning about a critical vulnerability")
                                                  : root.tr("Mentioned by CERT-SE")
        }
        return key
    }

    function dueText() {
        var x = page.it
        if (!x || !x.kev || !x.kev.due) return ""
        var d = Logic.daysBetween(Date.now(), Logic.parseDay(x.kev.due))
        var when = Logic.formatDay(Logic.parseDay(x.kev.due), root.lang)
        if (d < 0) return root.tr("%1 (passed)").arg(when)
        if (d === 0) return root.tr("%1 (today)").arg(when)
        return root.tr("%1 (in %2 days)").arg(when).arg(d)
    }

    Flickable {
        anchors { top: header.bottom; left: parent.left; right: parent.right; bottom: parent.bottom }
        contentHeight: col.height + units.gu(4)
        clip: true
        visible: page.it !== null

        Column {
            id: col
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: units.gu(2) }
            spacing: units.gu(1.5)

            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                textSize: Label.Large
                font.weight: Font.Medium
                text: page.it ? Logic.title(page.it) : ""
            }
            Label {
                width: parent.width
                visible: page.it !== null && page.it.kind === "cve" && page.it.name !== ""
                wrapMode: Text.WordWrap
                color: theme.palette.normal.backgroundSecondaryText
                text: page.it ? page.it.name : ""
            }

            // ---- Bedömning ------------------------------------------------
            Rectangle {
                width: parent.width
                height: verdict.height + units.gu(3)
                radius: units.gu(1)
                color: Qt.rgba(page.tint.r, page.tint.g, page.tint.b, 0.12)

                Column {
                    id: verdict
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: units.gu(1.5) }
                    spacing: units.gu(0.8)

                    Label {
                        text: page.it && page.it.handled ? root.tr("Handled")
                              : page.critical ? root.tr("Act now") : root.tr("Keep an eye on")
                        font.weight: Font.Medium
                        color: page.tint
                    }
                    Repeater {
                        model: page.it ? page.it.reasons : []
                        Item {
                            width: verdict.width
                            height: Math.max(reasonLabel.height, units.gu(2.2))
                            Icon {
                                id: dot
                                anchors { left: parent.left; top: parent.top; topMargin: units.gu(0.2) }
                                width: units.gu(1.8); height: width
                                name: modelData === "unscored" ? "info" : "tick"
                                color: theme.palette.normal.backgroundText
                            }
                            Label {
                                id: reasonLabel
                                anchors { left: dot.right; leftMargin: units.gu(1); right: parent.right }
                                wrapMode: Text.WordWrap
                                text: page.reasonText(modelData)
                            }
                        }
                    }
                }
            }

            // ---- Fakta ---------------------------------------------------
            Column {
                width: parent.width
                spacing: units.gu(0.6)
                Repeater {
                    model: {
                        var x = page.it
                        if (!x || x.kind !== "cve") return []
                        var rows = []
                        rows.push([root.tr("Platform"), root.tr("platformlong:" + x.platform)])
                        if (x.cvss >= 0) rows.push([root.tr("CVSS"), x.cvss.toFixed(1) + (x.cvssVersion ? "  (v" + x.cvssVersion + ")" : "")])
                        if (x.epss >= 0) rows.push([root.tr("EPSS"), (x.epss * 100).toFixed(1) + " %" +
                                                    (x.pct >= 0 ? "  " + root.tr("(higher than %1 % of all)").arg(Math.floor(x.pct * 100)) : "")])
                        if (x.kev) rows.push([root.tr("In KEV since"), Logic.formatDay(Logic.parseDay(x.kev.added), root.lang)])
                        if (x.kev && x.kev.due) rows.push([root.tr("CISA deadline"), page.dueText()])
                        if (x.published) rows.push([root.tr("Published"), Logic.formatDay(Date.parse(x.published), root.lang)])
                        if (x.vector) rows.push([root.tr("Vector"), x.vector.replace(/^CVSS:[0-9.]+\//, "")])
                        return rows
                    }
                    Item {
                        width: col.width
                        height: Math.max(keyLabel.height, valueLabel.height)
                        Label {
                            id: keyLabel
                            width: units.gu(14)
                            wrapMode: Text.WordWrap
                            color: theme.palette.normal.backgroundSecondaryText
                            text: modelData[0]
                        }
                        Label {
                            id: valueLabel
                            anchors { left: keyLabel.right; leftMargin: units.gu(1); right: parent.right }
                            wrapMode: Text.WrapAnywhere
                            text: modelData[1]
                        }
                    }
                }
            }

            // ---- Åtgärd och beskrivning ----------------------------------
            Label {
                visible: page.it !== null && page.it.kev !== null && page.it.kev.action !== ""
                text: root.tr("What CISA says to do")
                font.weight: Font.Medium
            }
            Label {
                width: parent.width
                visible: page.it !== null && page.it.kev !== null && page.it.kev.action !== ""
                wrapMode: Text.WordWrap
                text: page.it && page.it.kev ? page.it.kev.action : ""
            }
            Label {
                visible: page.it !== null && page.it.desc !== ""
                text: root.tr("Description")
                font.weight: Font.Medium
            }
            Label {
                width: parent.width
                visible: page.it !== null && page.it.desc !== ""
                wrapMode: Text.WordWrap
                text: page.it ? page.it.desc : ""
            }
            Label {
                width: parent.width
                visible: page.it !== null && page.it.kind === "certse" && page.it.cves.length > 0
                wrapMode: Text.WordWrap
                text: page.it && page.it.cves ? page.it.cves.join(", ") : ""
            }

            // ---- Länkar --------------------------------------------------
            Label { text: root.tr("Read more"); font.weight: Font.Medium }
            Repeater {
                model: {
                    var x = page.it
                    if (!x) return []
                    var out = []
                    for (var i = 0; i < x.certse.length; i++) out.push({ text: "CERT-SE: " + x.certse[i].title, url: x.certse[i].link })
                    if (x.kind === "cve") {
                        out.push({ text: root.tr("NVD (NIST)"), url: Logic.nvdLink(x.id) })
                        if (x.kev) out.push({ text: root.tr("CISA KEV catalog"), url: Logic.kevLink(x.id) })
                    }
                    return out
                }
                ListItem {
                    width: col.width
                    height: units.gu(6)
                    divider.visible: true
                    onClicked: Qt.openUrlExternally(modelData.url)
                    Label {
                        anchors { left: parent.left; right: linkIcon.left; rightMargin: units.gu(1); verticalCenter: parent.verticalCenter }
                        text: modelData.text
                        elide: Text.ElideRight
                    }
                    Icon {
                        id: linkIcon
                        anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                        width: units.gu(2); height: width
                        name: "external-link"
                        color: theme.palette.normal.backgroundSecondaryText
                    }
                }
            }
        }
    }
}
