// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "I18n.js" as I18n

Page {
    id: page

    readonly property var themeValues: ["auto", "light", "dark"]
    readonly property var langValues: ["auto"].concat(I18n.languages.map(function (l) { return l.code }))
    readonly property var levelValues: ["strict", "normal", "broad"]
    readonly property var windowValues: [14, 30, 60, 90]
    readonly property var bgValues: [0, 60, 180, 360]

    header: PageHeader {
        id: header
        title: root.tr("Settings")
    }

    Flickable {
        anchors { top: header.bottom; left: parent.left; right: parent.right; bottom: parent.bottom }
        contentHeight: content.height + units.gu(4)
        clip: true

        Column {
            id: content
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: units.gu(2) }
            spacing: units.gu(1.5)

            // ---- Nivå -----------------------------------------------------
            Label { text: root.tr("What counts as critical"); font.weight: Font.Medium }
            OptionSelector {
                width: parent.width
                expanded: true
                model: [root.tr("level:strict"), root.tr("level:normal") + " " + root.tr("(recommended)"), root.tr("level:broad")]
                selectedIndex: Math.max(0, page.levelValues.indexOf(root.level))
                onDelegateClicked: root.setLevel(page.levelValues[index])
            }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("help:" + root.level)
            }

            // ---- Plattformar ----------------------------------------------
            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Platforms"); font.weight: Font.Medium }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("Only vulnerabilities in what you turn on here are shown. The platform is read from the NVD's list of affected products (CPE), or from the vendor and product name.")
            }
            Repeater {
                model: ["windows", "linux", "apps", "virt", "device", "client"]
                Item {
                    width: content.width
                    height: Math.max(platCol.height, platSwitch.height) + units.gu(1)
                    Column {
                        id: platCol
                        anchors { left: parent.left; right: platSwitch.left; rightMargin: units.gu(2); verticalCenter: parent.verticalCenter }
                        Label { width: parent.width; wrapMode: Text.WordWrap; text: root.tr("platformlong:" + modelData) }
                        Label {
                            width: parent.width
                            wrapMode: Text.WordWrap
                            textSize: Label.Small
                            color: theme.palette.normal.backgroundSecondaryText
                            text: root.tr("platformhelp:" + modelData)
                        }
                    }
                    Switch {
                        id: platSwitch
                        anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                        checked: root.platforms[modelData] === true
                        onClicked: { var k = modelData, on = checked; Qt.callLater(function () { root.setPlatform(k, on) }) }
                    }
                }
            }

            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Time span"); font.weight: Font.Medium }
            OptionSelector {
                width: parent.width
                model: page.windowValues.map(function (d) { return root.tr("Last %1 days").arg(d) })
                selectedIndex: Math.max(0, page.windowValues.indexOf(root.windowDays))
                onDelegateClicked: root.setWindowDays(page.windowValues[index])
            }

            // ---- Bakgrund -------------------------------------------------
            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Check for new vulnerabilities"); font.weight: Font.Medium }
            OptionSelector {
                width: parent.width
                model: [root.tr("Only when the app is opened"), root.tr("Every hour"), root.tr("Every 3 hours"), root.tr("Every 6 hours")]
                selectedIndex: Math.max(0, page.bgValues.indexOf(root.bgMinutes))
                onDelegateClicked: root.setBgMinutes(page.bgValues[index])
            }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("Ubuntu Touch pauses apps that are not on screen. To check in the background, turn off app suspension for PatchNow in UT Tweak Tool and leave the app open.")
            }

            // ---- Larm -----------------------------------------------------
            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Alarms"); font.weight: Font.Medium }
            Label {
                width: parent.width
                visible: !root.alarmsEnabled
                wrapMode: Text.WordWrap
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("This version shows new critical vulnerabilities in the app only. A version that rings in the Clock app needs the calendar permission and is available from the project page on GitHub.")
            }
            Column {
                width: parent.width
                spacing: units.gu(1.5)
                visible: root.alarmsEnabled

                Item {
                    width: parent.width
                    height: Math.max(alarmLabel.height, alarmSwitch.height)
                    Label {
                        id: alarmLabel
                        anchors { left: parent.left; right: alarmSwitch.left; rightMargin: units.gu(2); verticalCenter: parent.verticalCenter }
                        wrapMode: Text.WordWrap
                        text: root.tr("Ring in the Clock app when something new is critical")
                    }
                    Switch {
                        id: alarmSwitch
                        anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                        checked: root.alarmOn
                        onClicked: root.setAlarmOn(checked)
                    }
                }
                Item {
                    width: parent.width
                    height: Math.max(quietLabel.height, quietSwitch.height)
                    Label {
                        id: quietLabel
                        anchors { left: parent.left; right: quietSwitch.left; rightMargin: units.gu(2); verticalCenter: parent.verticalCenter }
                        wrapMode: Text.WordWrap
                        text: root.tr("Quiet at night (%1–%2), ring at %2 instead").arg("22:00").arg("07:00")
                    }
                    Switch {
                        id: quietSwitch
                        anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                        enabled: root.alarmOn
                        checked: root.quietOn
                        onClicked: root.setQuietOn(checked)
                    }
                }
                Button {
                    text: root.tr("Test alarm (rings in 1 minute)")
                    onClicked: { root.testAlarm(); text = root.tr("Alarm set") }
                }
                Label {
                    width: parent.width
                    wrapMode: Text.WordWrap
                    textSize: Label.Small
                    color: theme.palette.normal.backgroundSecondaryText
                    text: root.tr("The alarm is a one-time alarm in the Clock app named “PatchNow: …”. Old ones are removed automatically.")
                }
            }

            // ---- Dolda leverantörer ---------------------------------------
            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Hidden vendors"); font.weight: Font.Medium }
            Label {
                width: parent.width
                visible: root.muted.length === 0
                wrapMode: Text.WordWrap
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("Swipe left on a vulnerability to hide a vendor you don't use.")
            }
            Repeater {
                model: root.muted
                Item {
                    width: content.width
                    height: units.gu(5)
                    Label {
                        anchors { left: parent.left; right: showButton.left; rightMargin: units.gu(1); verticalCenter: parent.verticalCenter }
                        text: modelData
                        elide: Text.ElideRight
                    }
                    Button {
                        id: showButton
                        anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                        text: root.tr("Show again")
                        onClicked: { var v = modelData; Qt.callLater(function () { root.unmuteVendor(v) }) }
                    }
                }
            }

            // ---- Utseende -------------------------------------------------
            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Theme"); font.weight: Font.Medium }
            OptionSelector {
                width: parent.width
                expanded: true
                model: [root.tr("Automatic"), root.tr("Light"), root.tr("Dark")]
                selectedIndex: Math.max(0, page.themeValues.indexOf(root.themeSetting))
                onDelegateClicked: root.setTheme(page.themeValues[index])
            }

            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Language"); font.weight: Font.Medium }
            OptionSelector {
                width: parent.width
                expanded: true
                model: [root.tr("Automatic (system language)")].concat(I18n.languages.map(function (l) { return l.name }))
                selectedIndex: Math.max(0, page.langValues.indexOf(root.langSetting))
                onDelegateClicked: root.setLanguage(page.langValues[index])
            }

            // ---- Om -------------------------------------------------------
            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("About"); font.weight: Font.Medium }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("PatchNow shows vulnerabilities that are being exploited or are about to be, so that you can skip the noise and patch what matters first.")
            }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("Sources: CISA Known Exploited Vulnerabilities catalog, the NVD (NIST), EPSS from FIRST (first.org/epss) and CERT-SE. PatchNow is not affiliated with any of them.")
            }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: "This product uses data from the NVD API but is not endorsed or certified by the NVD."
            }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("The assessment is a help for prioritising, not a guarantee. Always check the vendor's advisory.")
            }
            Label {
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("Version %1").arg(root.version) + " · © 2026 Johan Finn · GPLv3"
            }
        }
    }
}
