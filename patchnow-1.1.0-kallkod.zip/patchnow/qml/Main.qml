// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Storage.js" as Storage
import "Logic.js" as Logic
import "I18n.js" as I18n

MainView {
    id: root
    objectName: "mainView"
    applicationName: "patchnow.johanfinn"
    automaticOrientation: true

    width: units.gu(45)
    height: units.gu(argValue("height") !== "" ? parseInt(argValue("height"), 10) : 80)

    readonly property string version: "1.0.0"

    // Larm i Klocka-appen kräver behörigheten "calendar", som är reserverad och
    // granskas manuellt i OpenStore. Slå på: sätt true här och lägg till
    // "calendar" under policy_groups i patchnow.apparmor.
    readonly property bool alarmsEnabled: false

    readonly property bool isDark: theme.palette.normal.background.hslLightness < 0.5
    readonly property color criticalColor: isDark ? "#F0605A" : "#C7162B"
    readonly property color watchColor: isDark ? "#F5B041" : "#B45F06"

    // ---- Kommandoradsflaggor för test och skärmdumpar ---------------------
    // --demo   sparade svar från CISA, NVD och CERT-SE i stället för nätet
    // --lang=sv|en  --theme=light|dark  --page=settings|alert  --height=<gu>
    function argValue(name) {
        var args = Qt.application.arguments
        for (var i = 0; i < args.length; i++) {
            if (args[i] === "--" + name) return "1"
            if (args[i].indexOf("--" + name + "=") === 0) return args[i].substring(name.length + 3)
        }
        return ""
    }
    readonly property bool demo: argValue("demo") !== ""

    // ---- Inställningar --------------------------------------------------
    property string themeSetting: "auto"
    property string langSetting: "auto"
    property string level: "normal"          // strict | normal | broad
    property int windowDays: 30
    property int bgMinutes: 180              // 0 = bara när appen öppnas
    property bool alarmOn: true
    property bool quietOn: true
    readonly property int quietFrom: 22
    readonly property int quietTo: 7
    property var muted: []                   // leverantörer, gemener
    property var platforms: Logic.DEFAULT_PLATFORMS   // plattform -> bevakas
    property bool showHandled: false
    readonly property string lang: langSetting === "auto" ? I18n.systemLanguage(Qt.locale().name) : langSetting

    function tr(s) { return I18n.tr(s, lang) }

    function setTheme(value) { themeSetting = value; Storage.setSetting("theme", value); applyTheme() }
    function setLanguage(value) { langSetting = value; Storage.setSetting("language", value) }
    function setLevel(value) { level = value; Storage.setSetting("level", value); rebuild(false) }
    function setWindowDays(d) {
        windowDays = d
        Storage.setSetting("windowDays", d)
        rebuild(false)
        refresh(true)
    }
    function setBgMinutes(m) { bgMinutes = m; Storage.setSetting("bgMinutes", m) }
    function setAlarmOn(on) { alarmOn = on; Storage.setSetting("alarmOn", on ? "1" : "0") }
    function setQuietOn(on) { quietOn = on; Storage.setSetting("quietOn", on ? "1" : "0") }
    function setShowHandled(on) { showHandled = on; rebuild(false) }
    function setPlatform(key, on) {
        var p = {}
        for (var k in platforms) p[k] = platforms[k]
        p[key] = on
        platforms = p
        Storage.setSetting("platforms", JSON.stringify(p))
        rebuild(false)
    }
    function applyTheme() {
        if (themeSetting === "dark") theme.name = "Lomiri.Components.Themes.SuruDark"
        else if (themeSetting === "light") theme.name = "Lomiri.Components.Themes.Ambiance"
        else theme.name = ""
    }

    function muteVendor(vendor) {
        var v = vendor.toLowerCase()
        if (v === "" || muted.indexOf(v) >= 0) return
        muted = muted.concat([v])
        Storage.setSetting("muted", JSON.stringify(muted))
        rebuild(false)
    }
    function unmuteVendor(v) {
        muted = muted.filter(function (x) { return x !== v })
        Storage.setSetting("muted", JSON.stringify(muted))
        rebuild(false)
    }
    function setHandled(id, on) {
        Storage.setHandled(id, on, Date.now())
        rebuild(false)
    }
    // Från detaljsidan: stäng den först, sedan ändras listan (delegaten försvinner)
    function handleFromDetail(id, on) {
        stack.pop()
        setHandled(id, on)
    }

    // ---- Tid och bakgrund -----------------------------------------------
    property double now: Date.now()
    readonly property bool appActive: Qt.application.state === Qt.ApplicationActive
    readonly property int maxAgeMinutes: bgMinutes > 0 ? Math.max(10, bgMinutes - 5) : 50

    onAppActiveChanged: if (appActive) { now = Date.now(); refresh(false) }

    // Går även när appen inte syns, om telefonen inte fryser den
    // (UT Tweak Tool → Prevent app suspension).
    Timer {
        interval: Math.max(15, root.bgMinutes) * 60000
        repeat: true
        running: root.bgMinutes > 0 && !root.demo
        onTriggered: { root.now = Date.now(); root.refresh(false) }
    }

    // ---- Data -----------------------------------------------------------
    property var kevList: []          // CISA KEV, senaste 90 dagarna
    property string kevEtag: ""
    property var nvdKev: ({})         // NVD för KEV-poster i fönstret
    property var nvdRecent: ({})      // nya kritiska CVE:er (utanför KEV)
    property var epssMap: ({})
    property var feedList: []         // CERT-SE
    property double fetchedAt: 0
    property double nvdKevAt: 0
    property double nvdRecentAt: 0
    property double fullAt: 0
    property bool loading: false
    property var errors: ({})         // källa -> "offline" | "server" | "limit"

    property var items: []            // bedömda poster
    property int criticalCount: 0
    property int newCount: 0
    property int handledCount: 0
    property int hiddenCount: 0       // kritiska som plattformsfiltret döljer

    ListModel { id: alertModel }
    property alias alerts: alertModel

    function itemById(id) {
        for (var i = 0; i < items.length; i++) if (items[i].id === id) return items[i]
        return null
    }

    function save(key, value, t) { Storage.setCached(key, t, JSON.stringify(value)) }

    function loadCache() {
        function read(key, fallback) {
            var c = Storage.cached(key)
            if (!c) return fallback
            try { return JSON.parse(c.body) } catch (e) { return fallback }
        }
        kevList = read("kev", [])
        nvdKev = read("nvdKev", {})
        nvdRecent = read("nvdRecent", {})
        epssMap = read("epss", {})
        feedList = read("certse", [])
        var meta = read("meta", {})
        fetchedAt = meta.fetchedAt || 0
        nvdKevAt = meta.nvdKevAt || 0
        nvdRecentAt = meta.nvdRecentAt || 0
        fullAt = meta.fullAt || 0
        kevEtag = meta.kevEtag || ""
    }

    function saveMeta() {
        save("meta", { fetchedAt: fetchedAt, nvdKevAt: nvdKevAt, nvdRecentAt: nvdRecentAt,
                       fullAt: fullAt, kevEtag: kevEtag }, Date.now())
    }

    // ---- Hämtning -------------------------------------------------------
    property var pending: []          // [{ xhr, cb }]

    function get(url, cb, headers) {
        var xhr = new XMLHttpRequest()
        var entry = { xhr: xhr, cb: cb }
        pending.push(entry)
        xhr.onreadystatechange = function () {
            if (xhr.readyState !== XMLHttpRequest.DONE) return
            var i = pending.indexOf(entry)
            if (i < 0) return
            pending.splice(i, 1)
            cb(xhr.status, xhr.status === 200 ? xhr.responseText : "", xhr)
        }
        xhr.open("GET", url)
        if (headers) for (var h in headers) xhr.setRequestHeader(h, headers[h])
        xhr.send()
        watchdog.restart()
    }

    // Qt 5:s XHR saknar timeout
    Timer {
        id: watchdog
        interval: 60000
        onTriggered: {
            var list = root.pending
            root.pending = []
            for (var i = 0; i < list.length; i++) {
                list[i].xhr.onreadystatechange = function () {}
                list[i].xhr.abort()
                list[i].cb(0, "", null)
            }
        }
    }

    function errorKind(status) {
        if (status === 0) return "offline"
        if (status === 403 || status === 429 || status === 503) return "limit"
        return "server"
    }

    function setError(source, status) {
        var e = {}     // nytt objekt, annars uppdateras inte bindningarna
        for (var k in errors) e[k] = errors[k]
        e[source] = errorKind(status)
        errors = e
    }

    function refresh(force) {
        if (demo || loading) return
        now = Date.now()
        if (!force && fetchedAt > 0 && Logic.ageMinutes(fetchedAt, now) < maxAgeMinutes) return
        loading = true
        errors = ({})
        var t = now
        var full = force || t - fullAt > 86400000 || nvdKevAt === 0
        var left = 4
        function done() { if (--left === 0) fetchEpss(t, full) }

        // 1. CISA KEV (med ETag, så att ett oförändrat katalog bara ger 304)
        function onKev(status, text, xhr) {
            if (status === 304) { done(); return }
            if (status === 200) {
                try {
                    kevList = Logic.parseKev(text, Logic.dayKey(t - 90 * Logic.DAY)).list
                    kevEtag = (xhr && xhr.getResponseHeader("ETag")) || ""
                    save("kev", kevList, t)
                } catch (e) { setError("kev", 500) }
                done()
            } else if (url === Logic.KEV_URL) {
                url = Logic.KEV_MIRROR_URL
                get(url, onKev)
            } else { setError("kev", status); done() }
        }
        var url = Logic.KEV_URL
        get(url, onKev, kevEtag !== "" && kevList.length > 0 ? { "If-None-Match": kevEtag } : null)

        // 2. NVD: KEV-poster (fullt fönster en gång per dygn, annars ändringar)
        var since = t - windowDays * Logic.DAY
        var kevUrl = full ? Logic.nvdKevUrl(t, windowDays) : Logic.nvdKevChangesUrl(nvdKevAt - 3600000, t)
        get(kevUrl, function (status, text) {
            if (status === 200) {
                try {
                    var fresh = Logic.parseNvd(text)
                    nvdKev = full ? Logic.mergeNvd({}, fresh, since) : Logic.mergeNvd(nvdKev, fresh, since)
                    nvdKevAt = t
                    save("nvdKev", nvdKev, t)
                } catch (e) { setError("nvd", 500) }
            } else setError("nvd", status)
            done()
        })

        // 3. NVD: nya kritiska CVE:er
        var recentSince = t - Logic.RECENT_DAYS * Logic.DAY
        var recentUrl = full || nvdRecentAt === 0 ? Logic.nvdRecentUrl(t, Logic.RECENT_DAYS)
                                                  : Logic.nvdRecentChangesUrl(nvdRecentAt - 3600000, t)
        get(recentUrl, function (status, text) {
            if (status === 200) {
                try {
                    var fresh = Logic.parseNvd(text)
                    // bara sådant som inte redan är i KEV och är nyligen publicerat
                    var base = full ? {} : nvdRecent
                    nvdRecent = Logic.mergeNvd(base, fresh, recentSince)
                    nvdRecentAt = t
                    save("nvdRecent", nvdRecent, t)
                } catch (e) { setError("nvd", 500) }
            } else setError("nvd", status)
            done()
        })

        // 4. CERT-SE
        get(Logic.CERTSE_URL, function (status, text) {
            if (status === 200) {
                try { feedList = Logic.parseFeed(text); save("certse", feedList, t) }
                catch (e) { setError("certse", 500) }
            } else setError("certse", status)
            done()
        })
    }

    function fetchEpss(t, full) {
        var ids = Logic.epssCandidates(kevInWindow(), combinedNvd())
        var urls = Logic.epssUrls(ids)
        var left = urls.length
        var fresh = {}
        function finish() {
            if (Object.keys(fresh).length > 0) { epssMap = fresh; save("epss", epssMap, t) }
            fetchedAt = t
            if (full && !errors.nvd) fullAt = t
            saveMeta()
            loading = false
            if (argValue("debug") !== "") console.log("errors:", JSON.stringify(errors))
            rebuild(true)
        }
        if (left === 0) { finish(); return }
        for (var i = 0; i < urls.length; i++) {
            get(urls[i], function (status, text) {
                if (status === 200) {
                    try { var m = Logic.parseEpss(text); for (var k in m) fresh[k] = m[k] }
                    catch (e) { setError("epss", 500) }
                } else setError("epss", status)
                if (--left === 0) finish()
            })
        }
    }

    // ---- Bedömning ------------------------------------------------------
    function kevInWindow() {
        var since = Logic.dayKey(now - windowDays * Logic.DAY)
        return kevList.filter(function (k) { return k.added >= since })
    }

    function combinedNvd() {
        // Samma gräns som kevInWindow (hela dagar), annars tappar dagen längst bak sin CVSS
        var since = Logic.dayKey(now - windowDays * Logic.DAY)
        var out = {}
        for (var a in nvdRecent) out[a] = nvdRecent[a]
        for (var b in nvdKev) {
            var n = nvdKev[b]
            if (n.kevAdded && n.kevAdded < since) continue
            out[b] = n
        }
        return out
    }

    // notify: om nya kritiska poster ska ge larm (bara efter en riktig hämtning)
    function rebuild(notify) {
        now = Date.now()
        var list = Logic.merge(kevInWindow(), combinedNvd(), epssMap, feedList,
                               now - Logic.RECENT_DAYS * Logic.DAY, now - windowDays * Logic.DAY)
        var handled = Storage.handledMap()
        var res = Logic.assess(list, level, muted, handled, platforms)
        var all = res.items

        var seen = Storage.seenMap()
        var firstRun = Storage.setting("initialized", "0") !== "1"
        var crit = all.filter(function (it) { return it.tier === 2 && !it.handled })
        var newOnes = crit.filter(function (it) { return seen[it.id] === undefined })
        if (firstRun) {
            // Första hämtningen: allt som redan finns räknas som gammalt, inget larm.
            // (Inte 0: då rensar Storage.prune bort raderna vid nästa start.)
            if (fetchedAt > 0) {
                var old = now - 3 * Logic.DAY
                Storage.markSeen(crit.map(function (it) { return it.id }), old)
                for (var k = 0; k < crit.length; k++) seen[crit[k].id] = old
                Storage.setSetting("initialized", "1")
            }
        } else if (newOnes.length > 0) {
            Storage.markSeen(newOnes.map(function (it) { return it.id }), now)
            for (var j = 0; j < newOnes.length; j++) seen[newOnes[j].id] = now
        }

        var nNew = 0, nHandled = 0, nCrit = 0
        alertModel.clear()
        var shown = []
        for (var i = 0; i < all.length; i++) {
            var it = all[i]
            it.isNew = it.tier === 2 && !it.handled && seen[it.id] !== undefined &&
                       now - seen[it.id] < 2 * Logic.DAY
            if (it.isNew) nNew++
            if (it.handled) { nHandled++; if (!showHandled) continue }
            if (it.tier === 2 && !it.handled) nCrit++
            shown.push(it)
            alertModel.append({
                itemId: it.id, kind: it.kind, tier: it.tier, isNew: it.isNew, handled: it.handled,
                group: it.handled ? "handled" : (it.tier === 2 ? "critical" : "watch"),
                heading: Logic.title(it), cve: it.kind === "cve" ? it.id : "",
                cvss: it.cvss, epss: it.epss, date: it.date,
                ransomware: !!(it.kev && it.kev.ransomware), inKev: !!it.kev,
                certse: it.certse.length > 0, vendor: it.vendor, platform: it.platform
            })
        }
        items = all
        criticalCount = nCrit
        newCount = nNew
        handledCount = nHandled
        hiddenCount = res.hidden

        if (notify && !firstRun && newOnes.length > 0) scheduleAlarm(newOnes)
    }

    // ---- Larm i Klocka-appen (bara när alarmsEnabled) ---------------------
    Loader {
        id: alarmLoader
        active: root.alarmsEnabled
        sourceComponent: AlarmModel {}
    }
    Component { id: alarmComponent; Alarm {} }
    property var pendingAlarms: []
    readonly property string alarmPrefix: "PatchNow:"

    // Tar bort våra gamla engångslarm som redan har ringt.
    function cleanupAlarms() {
        var model = alarmLoader.item
        if (!model) return
        var doomed = []
        for (var i = 0; i < model.count; i++) {
            var a = model.get(i)
            if (a && a.message.indexOf(alarmPrefix) === 0 && a.date.getTime() < Date.now() - 60000) doomed.push(a)
        }
        for (var j = 0; j < doomed.length; j++) doomed[j].cancel()
    }

    function scheduleAlarm(newItems) {
        if (!alarmsEnabled || !alarmOn || !alarmLoader.item) return
        cleanupAlarms()
        var a = alarmComponent.createObject(root)
        a.message = Logic.alarmMessage(newItems)
        a.type = Alarm.OneTime
        a.date = new Date(Logic.alarmTime(Date.now(), quietOn, quietFrom, quietTo))
        a.enabled = true
        a.save()
        pendingAlarms.push(a)       // behåll referensen tills sparningen är klar
    }

    function testAlarm() {
        if (!alarmsEnabled || !alarmLoader.item) return
        var a = alarmComponent.createObject(root)
        a.message = alarmPrefix + " " + tr("Test alarm")
        a.type = Alarm.OneTime
        a.date = new Date(Date.now() + 60000)
        a.enabled = true
        a.save()
        pendingAlarms.push(a)
    }

    // ---- Demo -----------------------------------------------------------
    function fixture(name) {
        var xhr = new XMLHttpRequest()
        xhr.open("GET", Qt.resolvedUrl("../tests/fixtures/" + name), false)
        xhr.send()
        return xhr.responseText
    }

    function loadDemo() {
        Storage.useDatabase("patchnow-demo")
        var t = Date.now()
        kevList = Logic.parseKev(fixture("kev.json"), Logic.dayKey(t - 90 * Logic.DAY)).list
        nvdKev = Logic.parseNvd(fixture("nvd-kev.json"))
        nvdRecent = {}
        epssMap = {}
        feedList = Logic.parseFeed(fixture("certse.xml"))
        fetchedAt = t - 4 * 60000
        Storage.setSetting("initialized", "1")
        // Allt utom de två nyaste kritiska räknas som sett sedan tidigare
        var db = Storage.db()
        db.transaction(function (tx) { tx.executeSql("DELETE FROM seen"); tx.executeSql("DELETE FROM handled") })
        var list = Logic.merge(kevInWindow(), combinedNvd(), epssMap, feedList,
                               t - Logic.RECENT_DAYS * Logic.DAY, t - windowDays * Logic.DAY)
        var crit = Logic.assess(list, level, [], {}, platforms).items.filter(function (it) { return it.tier === 2 })
        Storage.markSeen(crit.slice(2).map(function (it) { return it.id }), t - 10 * Logic.DAY)
        Storage.markSeen(crit.slice(0, 2).map(function (it) { return it.id }), t - 3 * 3600000)
        Storage.setHandled(crit[crit.length - 1].id, true, t)
    }

    Component.onCompleted: {
        if (argValue("lang") !== "") langSetting = argValue("lang")
        if (demo) Storage.useDatabase("patchnow-demo")
        if (argValue("lang") === "") langSetting = Storage.setting("language", "auto")
        themeSetting = argValue("theme") !== "" ? argValue("theme") : Storage.setting("theme", "auto")
        level = Storage.setting("level", "normal")
        windowDays = parseInt(Storage.setting("windowDays", "30"), 10)
        bgMinutes = parseInt(Storage.setting("bgMinutes", "180"), 10)
        alarmOn = Storage.setting("alarmOn", "1") === "1"
        quietOn = Storage.setting("quietOn", "1") === "1"
        try { muted = JSON.parse(Storage.setting("muted", "[]")) } catch (e) { muted = [] }
        try {
            var p = JSON.parse(Storage.setting("platforms", "{}")), q = {}
            for (var k in Logic.DEFAULT_PLATFORMS) q[k] = p[k] !== undefined ? p[k] : Logic.DEFAULT_PLATFORMS[k]
            platforms = q
        } catch (e) { platforms = Logic.DEFAULT_PLATFORMS }
        if (demo) { level = "normal"; windowDays = 30; muted = []; platforms = Logic.DEFAULT_PLATFORMS; loadDemo() }
        else { loadCache(); Storage.prune(Date.now()) }
        applyTheme()
        rebuild(false)
        stack.push(Qt.resolvedUrl("AlertListPage.qml"))
        var page = argValue("page")
        if (page === "settings") stack.push(Qt.resolvedUrl("SettingsPage.qml"))
        else if (page === "alert" && items.length > 0)
            stack.push(Qt.resolvedUrl("AlertPage.qml"), { itemId: items[parseInt(argValue("index") || "0", 10)].id })
        if (argValue("simulate-new") !== "") simulateNew()
        else refresh(false)
    }

    // Test: låtsas att den nyaste kritiska posten just dök upp (--simulate-new)
    function simulateNew() {
        var crit = items.filter(function (it) { return it.tier === 2 && !it.handled })
        if (crit.length === 0) return
        Storage.forget(crit[0].id)
        rebuild(true)
        simTimer.start()
    }
    Timer {
        id: simTimer
        interval: 2500
        onTriggered: {
            var m = alarmLoader.item
            console.log("simulate-new: alarms =", m ? m.count : "inga (alarmsEnabled = false)")
            for (var i = 0; m && i < m.count; i++)
                console.log("  larm:", m.get(i).message, m.get(i).date, "enabled:", m.get(i).enabled)
        }
    }

    PageStack { id: stack }
}
