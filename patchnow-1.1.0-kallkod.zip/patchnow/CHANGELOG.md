# Changelog

## 1.1.0
- Same as 1.0.0, plus a one-time alarm in the Clock app when a new vulnerability becomes critical (needs the calendar permission). Quiet hours 22–07 and a test alarm.

## 1.0.0
- First version: actively exploited and critical vulnerabilities from CISA KEV, NVD, EPSS and CERT-SE, three levels, platform filter (Windows, Linux, server software and hypervisors by default; network devices and desktop/mobile hidden), background check, mark as handled, hide vendors. English and Swedish, light/dark theme.
