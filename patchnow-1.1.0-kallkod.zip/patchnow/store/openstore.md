# OpenStore – PatchNow

**Id:** patchnow.johanfinn
**Title:** PatchNow
**License:** GNU GPL v3
**Category:** Utilities

## Tag Line
Only the vulnerabilities your servers need patched now.

## Description
PatchNow cuts through the flood of new CVEs and shows only the vulnerabilities that need action now: the ones that are actively exploited and critical, on the platforms you run.

- Combines the CISA Known Exploited Vulnerabilities catalog, the NVD (CVSS and CISA's SSVC assessment), EPSS from FIRST and warnings from CERT-SE
- "Act now" list: actively exploited, CVSS 9 or higher and reachable over the network without login, plus ransomware-related and CERT-SE warnings
- Three levels: Strict, Normal and Broad
- Platform filter: Windows Server, Linux, server software and hypervisors by default. Network devices and desktop/mobile can be turned on
- Shows why each vulnerability is critical, CISA's deadline and required action, with links to NVD, CISA and CERT-SE
- Swipe right to mark as handled, swipe left to hide a vendor you don't use
- Checks in the background every 1, 3 or 6 hours (turn off app suspension in UT Tweak Tool)
- Works offline with the last saved data, stored locally in SQLite
- English and Swedish, light, dark or automatic theme

The assessment is a help for prioritising, not a guarantee. Always check the vendor's advisory.
This product uses data from the NVD API but is not endorsed or certified by the NVD. PatchNow is not affiliated with CISA, NIST, FIRST or CERT-SE.

**På svenska:** PatchNow visar bara de sårbarheter som behöver åtgärdas nu: de som utnyttjas aktivt och är kritiska, på de plattformar du har hand om. Appen hämtar data från CISA:s KEV-katalog, NVD, EPSS och CERT-SE och sorterar bort bruset. Svenska och engelska.

## Changelog 1.0.0
First version: actively exploited and critical vulnerabilities from CISA KEV, NVD, EPSS and CERT-SE, three levels, platform filter, background check, mark as handled, hide vendors. English and Swedish, light/dark theme.

## Screenshots (720×1200, English)
1. `1-list-light.png` – the list
2. `2-details-light.png` – why it is critical
3. `3-list-dark.png` – dark theme
4. `4-platforms-light.png` – platform filter
5. `5-details-dark.png` – details in dark theme

## Banner
`banner.svg` (1280×480)

## Version with alarms (1.1.0, GitHub Releases)
Same as 1.0.0, plus a one-time alarm in the Clock app when a new vulnerability becomes critical. Needs the calendar permission (manual review).
