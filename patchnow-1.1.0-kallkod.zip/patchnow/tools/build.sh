#!/bin/bash
# Bygger båda versionerna av PatchNow från samma källkod.
#   1.0.0  utan larm (OpenStore, bara behörigheten networking)
#   1.1.0  med larm i Klocka-appen (behörigheten calendar, manuell granskning)
# Kör från projektets rotkatalog: tools/build.sh
set -e
ROOT=$(cd "$(dirname "$0")/.." && pwd)
OUT=${OUT:-$ROOT/build}
CLICK="${CLICK:-/usr/bin/python3.12 /usr/bin/click}"
rm -rf "$OUT"; mkdir -p "$OUT"

stage() {   # stage <katalog>
    mkdir -p "$1"
    cp -r "$ROOT/qml" "$ROOT/assets" "$ROOT/manifest.json" "$ROOT/patchnow.apparmor" \
          "$ROOT/patchnow.desktop" "$ROOT/LICENSE" "$1/"
}

stage "$OUT/plain"
stage "$OUT/alarm"
A="$OUT/alarm"
sed -i 's/readonly property bool alarmsEnabled: false/readonly property bool alarmsEnabled: true/' "$A/qml/Main.qml"
sed -i 's/readonly property string version: "1.0.0"/readonly property string version: "1.1.0"/' "$A/qml/Main.qml"
sed -i 's/"version": "1.0.0"/"version": "1.1.0"/' "$A/manifest.json"
sed -i 's/"policy_groups": \["networking"\]/"policy_groups": ["networking", "calendar"]/' "$A/patchnow.apparmor"
grep -q 'alarmsEnabled: true' "$A/qml/Main.qml"
grep -q '"calendar"' "$A/patchnow.apparmor"
grep -q '"1.1.0"' "$A/manifest.json"

(cd "$OUT" && $CLICK build plain >/dev/null && $CLICK build alarm >/dev/null)
ls -1 "$OUT"/*.click
