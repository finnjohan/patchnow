#!/bin/bash
# Bygger båda versionerna av PatchNow från samma källkod.
#   X.Y.0  utan larm (OpenStore, bara behörigheten networking)
#   X.Y.1  med larm i Klocka-appen (behörigheten calendar, manuell granskning, GitHub Releases)
# Versionen läses ur manifest.json (ska sluta på .0). Kör från projektets rotkatalog: tools/build.sh
set -e
ROOT=$(cd "$(dirname "$0")/.." && pwd)
OUT=${OUT:-$ROOT/build}
CLICK="${CLICK:-/usr/bin/python3.12 /usr/bin/click}"
V=$(sed -n 's/.*"version": "\([0-9.]*\)".*/\1/p' "$ROOT/manifest.json")
case "$V" in *.0) ;; *) echo "versionen i manifest.json ska sluta på .0 ($V)"; exit 1;; esac
VA="${V%.0}.1"
grep -q "readonly property string version: \"$V\"" "$ROOT/qml/Main.qml" || { echo "Main.qml har inte version $V"; exit 1; }
rm -rf "$OUT"; mkdir -p "$OUT"

stage() {   # stage <katalog>
    mkdir -p "$1"
    cp -r "$ROOT/qml" "$ROOT/assets" "$ROOT/manifest.json" "$ROOT/patchnow.apparmor" \
          "$ROOT/patchnow.desktop" "$ROOT/LICENSE" "$1/"
}

stage "$OUT/plain"
stage "$OUT/alarm"
A="$OUT/alarm"
sed -i 's/readonly property bool alarmsEnabled: false/readonly property bool alarmsEnabled: true/' "$A/qml/Main.qml"
sed -i "s/readonly property string version: \"$V\"/readonly property string version: \"$VA\"/" "$A/qml/Main.qml"
sed -i "s/\"version\": \"$V\"/\"version\": \"$VA\"/" "$A/manifest.json"
sed -i 's/"policy_groups": \["networking"\]/"policy_groups": ["networking", "calendar"]/' "$A/patchnow.apparmor"
grep -q 'alarmsEnabled: true' "$A/qml/Main.qml"
grep -q "version: \"$VA\"" "$A/qml/Main.qml"
grep -q '"calendar"' "$A/patchnow.apparmor"
grep -q "\"$VA\"" "$A/manifest.json"
grep -q 'alarmsEnabled: false' "$OUT/plain/qml/Main.qml"

(cd "$OUT" && $CLICK build plain >/dev/null && $CLICK build alarm >/dev/null)
ls -1 "$OUT"/*.click
