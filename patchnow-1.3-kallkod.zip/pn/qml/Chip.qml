// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3

// Liten etikett, t.ex. "CVSS 9.8" eller "KEV".
Rectangle {
    id: chip
    property string text: ""
    property color tint: theme.palette.normal.backgroundSecondaryText
    property bool filled: false

    width: label.implicitWidth + units.gu(1.4)
    height: units.gu(2.4)
    radius: units.gu(0.6)
    color: filled ? tint : "transparent"
    border.width: filled ? 0 : units.dp(1)
    border.color: tint

    Label {
        id: label
        anchors.centerIn: parent
        text: chip.text
        textSize: Label.XSmall
        font.weight: Font.Medium
        color: chip.filled ? "white" : chip.tint
    }
}
