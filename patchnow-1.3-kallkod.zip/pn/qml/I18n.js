.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

// Enkel översättning. Källsträngarna är på engelska; här finns svenska.
// `en` behövs bara för nycklar som inte är text (nivåer och hjälptexter).

var languages = [
    { code: "en", name: "English" },
    { code: "sv", name: "Svenska" }
]

var en = {
    "platform:windows": "Windows",
    "platform:linux": "Linux",
    "platform:virt": "Hypervisor",
    "platformlong:windows": "Windows Server and Microsoft server software",
    "platformlong:linux": "Linux (kernel and distributions)",
    "platformlong:apps": "Server software on Windows or Linux",
    "platformlong:virt": "Hypervisors (VMware ESXi, vCenter, Proxmox)",
    "platformlong:device": "Network devices and appliances",
    "platformlong:client": "Desktop and mobile",
    "platformhelp:windows": "Windows, Exchange, SharePoint, SQL Server, IIS",
    "platformhelp:linux": "The Linux kernel, and packages in Red Hat, Debian, Ubuntu, SUSE and others",
    "platformhelp:apps": "Web servers, databases, PHP, Java, GitLab, Atlassian, WordPress and other programs you install on a server",
    "platformhelp:virt": "What your Windows and Linux servers run on",
    "platformhelp:device": "Cisco, Fortinet, Palo Alto, Citrix NetScaler, Ivanti Connect Secure, SonicWall, Synology and other firewalls, VPN boxes, routers and NAS",
    "platformhelp:client": "Apple, Android, Chrome, Firefox, Microsoft Office",
    "level:strict": "Strict",
    "level:normal": "Normal",
    "level:broad": "Broad",
    "help:strict": "Only actively exploited vulnerabilities with CVSS 9 or higher that can be attacked over the network without login, where CISA has not said the attack is hard to automate. New vulnerabilities outside the catalog need an EPSS of at least 70 %. About two a week.",
    "help:normal": "Actively exploited vulnerabilities with CVSS 9 or higher that can be attacked over the network without login, plus exploited ones used for ransomware or flagged by CERT-SE. New vulnerabilities need CVSS 9+ and an EPSS of at least 40 %. Two or three a week.",
    "help:broad": "Everything actively exploited with CVSS 8 or higher, or 7 and higher if reachable over the network without login. New vulnerabilities need CVSS 9+ and an EPSS of at least 20 %. Several a week."
}

var sv = {
    "platform:windows": "Windows",
    "platform:linux": "Linux",
    "platform:virt": "Hypervisor",
    "platformlong:windows": "Windows Server och Microsofts serverprogram",
    "platformlong:linux": "Linux (kärnan och distributioner)",
    "platformlong:apps": "Serverprogram på Windows eller Linux",
    "platformlong:virt": "Hypervisorer (VMware ESXi, vCenter, Proxmox)",
    "platformlong:device": "Nätverksutrustning och apparater",
    "platformlong:client": "Datorer och mobiler",
    "platformhelp:windows": "Windows, Exchange, SharePoint, SQL Server, IIS",
    "platformhelp:linux": "Linuxkärnan och paket i Red Hat, Debian, Ubuntu, SUSE med flera",
    "platformhelp:apps": "Webbservrar, databaser, PHP, Java, GitLab, Atlassian, WordPress och andra program man installerar på en server",
    "platformhelp:virt": "Det som era Windows- och Linuxservrar körs på",
    "platformhelp:device": "Cisco, Fortinet, Palo Alto, Citrix NetScaler, Ivanti Connect Secure, SonicWall, Synology och andra brandväggar, VPN-boxar, routrar och NAS",
    "platformhelp:client": "Apple, Android, Chrome, Firefox, Microsoft Office",
    "Platforms": "Plattformar",
    "Platform": "Plattform",
    "Software": "Program",
    "Software you run": "Program du kör",
    "Critical vulnerabilities (CVSS 9 or higher) in the programs you turn on are always shown and give an alarm, even before anyone exploits them. They are shown even if the vendor is hidden or the platform is turned off.":
        "Kritiska sårbarheter (CVSS 9 eller högre) i programmen du slår på visas alltid och ger larm, även innan någon utnyttjar dem. De visas även om leverantören är dold eller plattformen avstängd.",
    "You run %1 – critical vulnerabilities in it are always shown": "Du kör %1 – kritiska sårbarheter i det visas alltid",
    "Only vulnerabilities in what you turn on here are shown. The platform is read from the NVD's list of affected products (CPE), or from the vendor and product name.":
        "Bara sårbarheter i det du slår på här visas. Plattformen läses från NVD:s lista över drabbade produkter (CPE), eller från leverantörens och produktens namn.",
    "1 critical vulnerability in platforms you don't watch is hidden.": "1 kritisk sårbarhet på plattformar du inte bevakar är dold.",
    "%1 critical vulnerabilities in platforms you don't watch are hidden.": "%1 kritiska sårbarheter på plattformar du inte bevakar är dolda.",
    "Change under Settings → Platforms.": "Ändra under Inställningar → Plattformar.",
    "level:strict": "Strikt",
    "level:normal": "Normal",
    "level:broad": "Bred",
    "help:strict": "Bara sårbarheter som utnyttjas aktivt, har CVSS 9 eller högre och kan angripas över nätet utan inloggning, och där CISA inte bedömt att attacken är svår att automatisera. Nya sårbarheter utanför katalogen kräver EPSS på minst 70 %. Ungefär två i veckan.",
    "help:normal": "Sårbarheter som utnyttjas aktivt, har CVSS 9 eller högre och kan angripas över nätet utan inloggning, och dessutom utnyttjade som används för ransomware eller som CERT-SE varnar för. Nya sårbarheter kräver CVSS 9+ och EPSS på minst 40 %. Två eller tre i veckan.",
    "help:broad": "Allt som utnyttjas aktivt med CVSS 8 eller högre, eller 7 och högre om det nås över nätet utan inloggning. Nya sårbarheter kräver CVSS 9+ och EPSS på minst 20 %. Flera i veckan.",

    // Listan
    "Settings": "Inställningar",
    "Refresh": "Uppdatera",
    "Checking…": "Kollar…",
    "No data yet": "Inga data än",
    "Nothing critical right now": "Inget kritiskt just nu",
    "1 vulnerability to act on now": "1 sårbarhet att åtgärda nu",
    "%1 vulnerabilities to act on now": "%1 sårbarheter att åtgärda nu",
    "1 new in the last 48 hours": "1 ny de senaste två dygnen",
    "%1 new in the last 48 hours": "%1 nya de senaste två dygnen",
    "Checked %1": "Kollat %1",
    "Level: %1": "Nivå: %1",
    "last %1 days": "senaste %1 dagarna",
    "No connection. Showing what was saved %1.": "Ingen anslutning. Visar det som sparades %1.",
    "%1 is busy right now (rate limit). Trying again later.": "%1 har för mycket att göra just nu (begränsning). Försöker igen senare.",
    "Could not reach %1. The assessment may be incomplete.": "Kunde inte nå %1. Bedömningen kan vara ofullständig.",
    "Act now": "Åtgärda nu",
    "Keep an eye on": "Bevaka",
    "Handled": "Åtgärdat",
    "Exploited": "Utnyttjas",
    "Ransomware": "Ransomware",
    "NEW": "NY",
    "Mark as handled": "Markera som åtgärdad",
    "Not handled": "Inte åtgärdad",
    "Hide this vendor": "Dölj leverantören",
    "No actively exploited or critical vulnerabilities in this period.": "Inga aktivt utnyttjade eller kritiska sårbarheter under perioden.",
    "Show handled (%1)": "Visa åtgärdade (%1)",
    "Hide handled": "Dölj åtgärdade",
    "Swipe right to mark as handled, left to hide a vendor.": "Svep åt höger för att markera som åtgärdad, åt vänster för att dölja en leverantör.",

    // Detaljsidan
    "Open in browser": "Öppna i webbläsaren",
    "Actively exploited – in CISA's catalog of known exploited vulnerabilities since %1":
        "Utnyttjas aktivt – finns i CISA:s katalog över utnyttjade sårbarheter sedan %1",
    "CVSS %1 of 10": "CVSS %1 av 10",
    "No CVSS score from NVD yet": "NVD har inte satt någon CVSS-poäng än",
    "Can be attacked over the network without login or user interaction": "Kan angripas över nätet utan inloggning och utan att någon behöver klicka",
    "CISA: exploitation can be automated and gives full control": "CISA: attacken kan automatiseras och ger full kontroll",
    "The description says code can be run without logging in": "Enligt beskrivningen kan kod köras utan inloggning",
    "Used in ransomware campaigns": "Används i ransomware-attacker",
    "EPSS %1 % – high probability of exploitation in the next 30 days": "EPSS %1 % – stor risk att den utnyttjas inom 30 dagar",
    "CERT-SE warns about it": "CERT-SE varnar för den",
    "CERT-SE has published a warning about a critical vulnerability": "CERT-SE har gått ut med en varning om en kritisk sårbarhet",
    "Mentioned by CERT-SE": "Nämns av CERT-SE",
    "%1 (passed)": "%1 (passerat)",
    "%1 (today)": "%1 (i dag)",
    "%1 (in %2 days)": "%1 (om %2 dagar)",
    "CVSS": "CVSS",
    "EPSS": "EPSS",
    "(higher than %1 % of all)": "(högre än %1 % av alla)",
    "In KEV since": "I KEV sedan",
    "CISA deadline": "CISA:s tidsfrist",
    "Published": "Publicerad",
    "Vector": "Vektor",
    "What CISA says to do": "Vad CISA säger att man ska göra",
    "Description": "Beskrivning",
    "Read more": "Läs mer",
    "NVD (NIST)": "NVD (NIST)",
    "CISA KEV catalog": "CISA:s KEV-katalog",

    // Inställningar
    "What counts as critical": "Vad som räknas som kritiskt",
    "(recommended)": "(rekommenderas)",
    "Time span": "Tidsperiod",
    "Last %1 days": "Senaste %1 dagarna",
    "Check for new vulnerabilities": "Leta efter nya sårbarheter",
    "Only when the app is opened": "Bara när appen öppnas",
    "Every hour": "Varje timme",
    "Every 3 hours": "Var 3:e timme",
    "Every 6 hours": "Var 6:e timme",
    "Ubuntu Touch pauses apps that are not on screen. To check in the background, turn off app suspension for PatchNow in UT Tweak Tool and leave the app open.":
        "Ubuntu Touch pausar appar som inte syns på skärmen. För att kolla i bakgrunden: stäng av pausningen (suspension) för PatchNow i UT Tweak Tool och låt appen vara öppen.",
    "Alarms": "Larm",
    "This version shows new critical vulnerabilities in the app only. A version that rings in the Clock app needs the calendar permission and is available from the project page on GitHub.":
        "Den här versionen visar nya kritiska sårbarheter bara i appen. En version som larmar i Klocka-appen behöver behörigheten för kalendern och finns på projektets sida på GitHub.",
    "Ring in the Clock app when something new is critical": "Larma i Klocka-appen när något nytt är kritiskt",
    "Quiet at night (%1–%2), ring at %2 instead": "Tyst på natten (%1–%2), larma kl. %2 i stället",
    "Test alarm (rings in 1 minute)": "Testlarm (ringer om 1 minut)",
    "Alarm set": "Larmet är satt",
    "Test alarm": "Testlarm",
    "The alarm is a one-time alarm in the Clock app named “PatchNow: …”. Old ones are removed automatically.":
        "Larmet är ett engångslarm i Klocka-appen som heter ”PatchNow: …”. Gamla larm tas bort automatiskt.",
    "Hidden vendors": "Dolda leverantörer",
    "Swipe left on a vulnerability to hide a vendor you don't use.": "Svep åt vänster på en sårbarhet för att dölja en leverantör ni inte använder.",
    "Show again": "Visa igen",
    "Theme": "Tema",
    "Automatic": "Automatiskt",
    "Light": "Ljust",
    "Dark": "Mörkt",
    "Language": "Språk",
    "Automatic (system language)": "Automatiskt (systemets språk)",
    "About": "Om",
    "PatchNow shows vulnerabilities that are being exploited or are about to be, so that you can skip the noise and patch what matters first.":
        "PatchNow visar sårbarheter som utnyttjas eller snart kommer att utnyttjas, så att du slipper bruset och kan patcha det viktigaste först.",
    "Sources: CISA Known Exploited Vulnerabilities catalog, the NVD (NIST), EPSS from FIRST (first.org/epss) and CERT-SE. PatchNow is not affiliated with any of them.":
        "Källor: CISA:s katalog Known Exploited Vulnerabilities, NVD (NIST), EPSS från FIRST (first.org/epss) och CERT-SE. PatchNow har ingen koppling till någon av dem.",
    "The assessment is a help for prioritising, not a guarantee. Always check the vendor's advisory.":
        "Bedömningen är ett stöd för att prioritera, ingen garanti. Läs alltid leverantörens egen information.",
    "Version %1": "Version %1"
}

var tables = { sv: sv, en: en }

function systemLanguage(localeName) {
    var code = (localeName || "en").substring(0, 2)
    return code === "sv" ? "sv" : "en"
}

function tr(s, lang) {
    var t = tables[lang]
    if (t && t[s] !== undefined) return t[s]
    if (en[s] !== undefined) return en[s]
    return s
}
