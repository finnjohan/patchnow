.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
.import QtQuick.LocalStorage 2.0 as Sql

var _db = null
var _name = "patchnow"

// Demoläget (--demo) använder en egen databas så att riktiga data inte rörs.
function useDatabase(name) {
    _name = name
    _db = null
}

function db() {
    if (_db) return _db
    _db = Sql.LocalStorage.openDatabaseSync(_name, "1.0", "PatchNow", 20000000)
    _db.transaction(function (tx) {
        tx.executeSql("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
        // Senaste tolkade svaret per källa, så att listan syns utan nät
        tx.executeSql("CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, fetched INTEGER NOT NULL, body TEXT NOT NULL)")
        // När en post först dök upp som kritisk (för "ny" och larm)
        tx.executeSql("CREATE TABLE IF NOT EXISTS seen (id TEXT PRIMARY KEY, first INTEGER NOT NULL)")
        // Poster som användaren markerat som åtgärdade
        tx.executeSql("CREATE TABLE IF NOT EXISTS handled (id TEXT PRIMARY KEY, at INTEGER NOT NULL)")
    })
    return _db
}

function setting(key, fallback) {
    var v = fallback
    db().readTransaction(function (tx) {
        var rs = tx.executeSql("SELECT value FROM settings WHERE key = ?", [key])
        if (rs.rows.length > 0 && rs.rows.item(0).value !== null) v = rs.rows.item(0).value
    })
    return v
}

function setSetting(key, value) {
    db().transaction(function (tx) {
        tx.executeSql("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", [key, String(value)])
    })
}

// ---- Cache -----------------------------------------------------------------

function cached(key) {
    var v = null
    db().readTransaction(function (tx) {
        var rs = tx.executeSql("SELECT fetched, body FROM cache WHERE key = ?", [key])
        if (rs.rows.length > 0) v = { fetched: rs.rows.item(0).fetched, body: rs.rows.item(0).body }
    })
    return v
}

function setCached(key, fetched, body) {
    db().transaction(function (tx) {
        tx.executeSql("INSERT OR REPLACE INTO cache (key, fetched, body) VALUES (?, ?, ?)", [key, fetched, body])
    })
}

// ---- Sedda och åtgärdade ---------------------------------------------------

function seenMap() {
    var out = {}
    db().readTransaction(function (tx) {
        var rs = tx.executeSql("SELECT id, first FROM seen")
        for (var i = 0; i < rs.rows.length; i++) out[rs.rows.item(i).id] = rs.rows.item(i).first
    })
    return out
}

function markSeen(ids, at) {
    db().transaction(function (tx) {
        for (var i = 0; i < ids.length; i++)
            tx.executeSql("INSERT OR IGNORE INTO seen (id, first) VALUES (?, ?)", [ids[i], at])
    })
}

function forget(id) {
    db().transaction(function (tx) { tx.executeSql("DELETE FROM seen WHERE id = ?", [id]) })
}

function handledMap() {
    var out = {}
    db().readTransaction(function (tx) {
        var rs = tx.executeSql("SELECT id FROM handled")
        for (var i = 0; i < rs.rows.length; i++) out[rs.rows.item(i).id] = true
    })
    return out
}

function setHandled(id, on, at) {
    db().transaction(function (tx) {
        if (on) tx.executeSql("INSERT OR REPLACE INTO handled (id, at) VALUES (?, ?)", [id, at])
        else tx.executeSql("DELETE FROM handled WHERE id = ?", [id])
    })
}

// Rensar sedda/åtgärdade poster som är äldre än ett halvår.
function prune(nowMs) {
    var limit = nowMs - 183 * 86400000
    db().transaction(function (tx) {
        tx.executeSql("DELETE FROM seen WHERE first < ?", [limit])
        tx.executeSql("DELETE FROM handled WHERE at < ?", [limit])
    })
}
