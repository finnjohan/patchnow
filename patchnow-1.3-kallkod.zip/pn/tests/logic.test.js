// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
// Kör: node tests/logic.test.js
const fs = require("fs"), vm = require("vm"), path = require("path")
const src = fs.readFileSync(path.join(__dirname, "../qml/Logic.js"), "utf8").replace(/^\.pragma library.*$/m, "")
const L = {}; vm.createContext(L); vm.runInContext(src, L)
const fx = n => fs.readFileSync(path.join(__dirname, "fixtures", n), "utf8")
let fails = 0
function ok(c, msg) { if (!c) { fails++; console.log("FEL:", msg) } else console.log("ok ", msg) }

// Adresser
ok(L.nvdDate(Date.UTC(2026, 10, 19, 7, 5, 9)) === "2026-11-19T07:05:09.000", "nvdDate")
ok(L.nvdKevUrl(Date.UTC(2026, 10, 19), 200).indexOf("kevStartDate=2026-08-21T00:00:00.000") > 0, "KEV-intervallet kapas till 90 dagar")
ok(L.nvdRecentUrl(0, 10).indexOf("cvssV3Severity=CRITICAL") > 0, "recent-url")
const ids = Array.from({ length: 120 }, (_, i) => "CVE-2026-1" + String(i).padStart(5, "0"))
const eu = L.epssUrls(ids)
ok(eu.length === 3 && eu.every(u => u.split("cve=")[1].length < 2000), "EPSS i omgångar under 2000 tecken")

ok(L.nvdKevChangesUrl(0, 1).indexOf("hasKev&lastModStartDate=") > 0, "ändrings-url")
const mn = L.mergeNvd({ A: { kevAdded: "2026-01-01" }, B: { kevAdded: "2026-11-01", cvss: -1 } },
                      { B: { kevAdded: "2026-11-01", cvss: 9.8 }, C: { published: "2026-11-18T10:00:00.000" } },
                      new Date(2026, 9, 1).getTime())
ok(!mn.A && mn.B.cvss === 9.8 && mn.C, "mergeNvd ersätter och rensar")

// Tolkning
const kev = L.parseKev(fx("kev.json"), "2026-10-20")
ok(kev.list.length > 20 && kev.list.every(k => k.added >= "2026-10-20"), "parseKev filtrerar på datum (" + kev.list.length + ")")
const nvd = L.parseNvd(fx("nvd-kev.json"))
ok(nvd["CVE-2026-97229"].cvss === 10 && L.remoteNoAuth(nvd["CVE-2026-97229"].vector), "parseNvd CVSS och vektor")
ok(nvd["CVE-2015-3306"].ssvc.automatable === "yes", "parseNvd SSVC")
const epss = L.parseEpss('{"status":"OK","data":[{"cve":"CVE-1","epss":"0.912340000","percentile":"0.99"}]}')
ok(Math.abs(epss["CVE-1"].epss - 0.91234) < 1e-9, "parseEpss strängar till tal")
const feed = L.parseFeed(fx("certse.xml"))
ok(feed.length === 5 && feed[0].critical && feed[0].cves[0] === "CVE-2026-114938", "parseFeed Atom + CVE i content")
ok(!feed[1].critical && feed[4].cves[0] === "CVE-2026-98432", "parseFeed icke-kritisk titel")
const rss = L.parseFeed('<rss><channel><item><title>Critical flaw &amp; more</title><link>https://x/y</link><pubDate>Tue, 17 Nov 2026 10:00:00 GMT</pubDate><description><![CDATA[CVE-2026-1234]]></description></item></channel></rss>')
ok(rss[0].critical && rss[0].link === "https://x/y" && rss[0].cves[0] === "CVE-2026-1234" && rss[0].published > 0, "parseFeed RSS 2.0")

// Bedömning med riktiga data
const now = new Date(2026, 10, 19, 9, 0).getTime()
const all = { windows: true, linux: true, apps: true, virt: true, device: true, client: true }
const list = L.merge(kev.list, nvd, {}, feed, now - 10 * L.DAY, now - 30 * L.DAY)
for (const lvl of ["strict", "normal", "broad"]) {
    const a = L.assess(JSON.parse(JSON.stringify(list)), lvl, [], {}, all).items
    const crit = a.filter(x => x.tier === 2)
    console.log("    " + lvl + ": " + crit.length + " kritiska av " + a.length + " (KEV sedan 20 okt)")
}
const norm = L.assess(list, "normal", [], {}, all).items
const byId = id => norm.find(x => x.id === id)
ok(byId("CVE-2026-90436").tier === 2, "Apache Axis RCE (KEV, 9.8, nät) är kritisk")
ok(byId("CVE-2026-123039").tier === 1, "Check Point 7.8 lokalt bevakas bara")
ok(norm[0].tier === 2 && norm[norm.length - 1].tier === 1, "kritiska sorteras först")
ok(norm.some(x => x.kind === "certse" && x.tier === 2), "CERT-SE:s 'Kritisk sårbarhet' blir egen post")
const muted = L.assess(JSON.parse(JSON.stringify(list)), "normal", ["apache"], {}, all).items
ok(!muted.some(x => x.vendor === "Apache"), "tystad leverantör döljs")
const h = L.assess(JSON.parse(JSON.stringify(list)), "normal", [], { "CVE-2026-90436": true }, all).items
ok(h[h.length - 1].id === "CVE-2026-90436", "åtgärdad hamnar sist")

// Plattform: riktiga CPE:er från NVD och KEV:s namn
const plat = {}
for (const it of norm) plat[it.id] = it.platform
const expect = {
    "CVE-2026-96951": "windows",   // Microsoft Windows
    "CVE-2026-46300": "linux",     // Linux Kernel
    "CVE-2015-3306": "apps",       // ProFTPD (paket i Debian/SUSE)
    "CVE-2024-10441": "device",    // Synology DSM
    "CVE-2026-116606": "device",   // Barracuda ESG
    "CVE-2026-111560": "device",   // Barracuda, flera produkter
    "CVE-2026-76418": "device",    // Cisco ASA/FTD
    "CVE-2026-76519": "device",    // Cisco Secure Email Gateway
    "CVE-2026-0322": "device",     // PAN-OS
    "CVE-2025-61624": "device",    // Fortinet
    "CVE-2026-104935": "device",   // Ivanti Connect Secure
    "CVE-2026-88779": "device",    // NetScaler
    "CVE-2026-19868": "device",    // SonicWall
    "CVE-2026-114625": "device",   // Arista VeloCloud
    "CVE-2026-102764": "device",   // BeyondTrust Remote Support
    "CVE-2026-41709": "virt",      // VMware ESXi
    "CVE-2024-27834": "client",    // Apple
    "CVE-2026-124194": "client",   // Microsoft Office
    "CVE-2026-125350": "client",   // Chrome
    "CVE-2026-97229": "apps",      // GitLab
    "CVE-2026-109618": "apps",     // PHP
    "CVE-2026-111497": "apps",     // Brotli
    "CVE-2026-21589": "apps",      // Atlassian
    "CVE-2026-123218": "apps",     // Aspera, körs på Linux
    "CVE-2026-90436": "apps",      // Apache Axis, inga CPE:er än
    "CVE-2026-123158": "apps"      // OpenSSH
}
const wrong = Object.entries(expect).filter(([id, p]) => plat[id] !== undefined && plat[id] !== p)
ok(wrong.length === 0, "plattform för " + Object.keys(expect).filter(id => plat[id]).length + " kända poster" + (wrong.length ? ": " + wrong.map(([id, p]) => id + " blev " + plat[id] + ", väntat " + p).join("; ") : ""))
ok(L.platformOf({ vendor: "Cisco", product: "IOS XE", name: "", cpes: [] }) === "device", "Cisco utan CPE = utrustning")
ok(L.platformOf({ vendor: "Microsoft", product: "Exchange Server", name: "", cpes: [] }) === "windows", "Exchange utan CPE = Windows")
ok(L.platformOf({ kind: "certse", vendor: "CERT-SE", product: "", name: "Kritisk sårbarhet i Oracle Java", cpes: [] }) === "apps", "CERT-SE Java = serverprogram")
const def = L.assess(JSON.parse(JSON.stringify(list)), "normal", [], {}, L.DEFAULT_PLATFORMS)
ok(!def.items.some(x => x.platform === "device" || x.platform === "client") && def.hidden > 0, "standard: utrustning och klienter döljs (" + def.hidden + " kritiska dolda)")
const crit = (r) => r.items.filter(x => x.tier === 2).length
console.log("    normal: " + crit(L.assess(JSON.parse(JSON.stringify(list)), "normal", [], {}, all)) + " kritiska utan filter, " + crit(def) + " med standardfiltret")

// Utan KEV: CVSS + EPSS
const fresh = { kind: "cve", id: "X", vendor: "", product: "", desc: "", kev: null, cvss: 9.8,
                vector: "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H", ssvc: {}, epss: 0.5, certse: [] }
ok(L.evaluate(fresh, "normal").tier === 2 && L.evaluate(fresh, "strict").tier === 1, "EPSS-gräns per nivå")
fresh.epss = 0.01
ok(L.evaluate(fresh, "broad").tier === 0, "ny CVE utan exploateringstecken visas inte")
// Utan poäng: beskrivningen räddar
const unscored = { kind: "cve", id: "Y", vendor: "", product: "", kev: { ransomware: false }, cvss: -1, vector: "", ssvc: {}, epss: -1, certse: [],
    desc: "An unauthenticated remote attacker can execute arbitrary code via a crafted request." }
ok(L.evaluate(unscored, "normal").tier === 2 && L.evaluate(unscored, "strict").tier === 1, "KEV utan CVSS men oautentiserad RCE")

ok(L.title({ kind: "cve", vendor: "GPUStack", product: "GPUStack" }) === "GPUStack", "titel utan dubbelt namn")
ok(L.title({ kind: "cve", vendor: "Barracuda Networks", product: "Barracuda Email Security Gateway (ESG)" }) === "Barracuda Email Security Gateway (ESG)", "titel: produkten räcker")
ok(L.title({ kind: "cve", vendor: "Synology", product: "DiskStation Manager (DSM)" }) === "Synology DiskStation Manager (DSM)", "titel: leverantör + produkt")
ok(L.title({ kind: "cve", id: "CVE-1", vendor: "", product: "", name: "Foo Bar RCE Vulnerability" }) === "Foo Bar RCE", "titel från KEV-namnet i NVD")

// ---- Program du kör (1.2 + 1.3) ----------------------------------------------
const rec = L.parseNvd(fx("nvd-recent.json"))
const on = (...ks) => Object.fromEntries(ks.map(k => [k, true]))
const allSw = on(...L.SOFTWARE)
const recItem = id => ({ kind: "cve", id, vendor: "", product: "", name: "", desc: rec[id].desc, cpes: rec[id].cpes, sw: rec[id].sw,
                          kev: null, cvss: rec[id].cvss, vector: rec[id].vector, ssvc: rec[id].ssvc, epss: -1, certse: [] })
const swOf = (id, s) => L.softwareOf(recItem(id), s || allSw)
ok(L.SOFTWARE.length === 11 && L.SOFTWARE.every(k => L.SOFTWARE_NAMES[k] && L.SOFTWARE_SHORT[k] && L.SW_CPE[k] && L.SW_NAME[k] && L.SW_DESC[k]), "alla 11 program har namn och regler")
ok(swOf("CVE-2024-38476") === "apache", "Apache httpd via CPE")
ok(swOf("CVE-2025-1974") === "nginx", "ingress-nginx utan CPE via beskrivningen")
ok(swOf("CVE-2024-8926") === "php", "PHP via CPE")
ok(swOf("CVE-2026-13370") === "", "SourceCodester-app i PHP med MySQL räknas varken som PHP eller MySQL")
ok(swOf("CVE-2024-38812") === "vmware", "vCenter via CPE")
ok(swOf("CVE-2024-23897") === "jenkins", "Jenkins via CPE")
ok(swOf("CVE-2023-7028") === "gitlab", "GitLab via CPE")
ok(swOf("CVE-2016-6662") === "mysql", "MySQL/MariaDB via CPE")
ok(swOf("CVE-2024-21545") === "proxmox", "Proxmox VE utan CPE via beskrivningen")
ok(swOf("CVE-2022-22947") === "", "Spring Cloud Gateway (a:vmware:spring…) räknas inte som VMware")
ok(swOf("CVE-2024-38812", on("gitlab")) === "", "vCenter visas inte när bara GitLab är valt")
// Beskrivning utan CPE, som ett nytt VMSA innan NVD har analyserat det
const noCpe = (desc, extra) => Object.assign({ kind: "cve", id: "N", vendor: "", product: "", name: "", desc, cpes: [], sw: [] }, extra || {})
ok(L.softwareOf(noCpe("VMware vCenter Server contains an authentication bypass vulnerability in the VMware Directory Service."), allSw) === "vmware", "VMSA utan CPE: vCenter")
ok(L.softwareOf(noCpe("VMware ESX contains a heap out-of-bounds write vulnerability."), allSw) === "vmware", "VMSA utan CPE: ESX")
ok(L.softwareOf(noCpe("VMware ESXi, Workstation, and Fusion contain an out-of-bounds write in the XHCI USB controller."), allSw) === "vmware", "ESXi + Workstation räknas")
ok(L.softwareOf(noCpe("VMware Workstation and Fusion contain a use-after-free vulnerability."), allSw) === "", "bara Workstation/Fusion räknas inte")
ok(L.softwareOf(noCpe("VMware Tools for Windows contains an authentication bypass in VGAuth."), allSw) === "vmware", "VMware Tools räknas")
ok(L.softwareOf(noCpe("In Spring Framework versions 6.1.0 - 6.1.5 (VMware Tanzu) …"), allSw) === "", "Spring/Tanzu räknas inte")
ok(L.softwareOf(noCpe("Vulnerability in the MySQL Server product of Oracle MySQL (component: Server: Optimizer)."), allSw) === "mysql", "MySQL Server utan CPE")
ok(L.softwareOf(noCpe("MariaDB Server 11.4 before 11.4.5 allows a crash."), allSw) === "mysql", "MariaDB utan CPE")
ok(L.softwareOf(noCpe("Vulnerability in the MySQL Connectors product of Oracle MySQL (component: Connector/J)."), allSw) === "", "MySQL Connector räknas inte")
ok(L.softwareOf(noCpe("Online Shop 1.0 is vulnerable to SQL injection via id; the backend is MySQL 5.7."), allSw) === "", "SQL-injektion mot MySQL räknas inte")
ok(L.softwareOf(noCpe("An issue has been discovered in GitLab EE affecting all versions starting from 17.0."), allSw) === "gitlab", "GitLab EE utan CPE")
ok(L.softwareOf(noCpe("Jenkins GitLab Plugin 1.9.1 and earlier does not perform a permission check."), on("gitlab")) === "", "Jenkins GitLab Plugin räknas inte som GitLab")
ok(L.softwareOf(noCpe("Jenkins GitLab Plugin 1.9.1 and earlier does not perform a permission check."), allSw) === "jenkins", "… men som Jenkins")
ok(L.softwareOf(noCpe("x", { cpes: ["a:jenkins:script_security"], sw: ["jenkins"] }), on("jenkins")) === "jenkins", "Jenkins-tillägg via CPE")
ok(L.softwareOf(noCpe("Proxmox Backup Server before 3.2 allows …"), allSw) === "proxmox", "Proxmox Backup Server")
// KEV-namn och CERT-SE-rubriker
const kevIt = (vendor, product) => ({ kind: "cve", id: "K", vendor, product, name: "", desc: "", cpes: [], sw: [] })
ok(L.softwareOf(kevIt("VMware", "vCenter Server"), allSw) === "vmware", "KEV: VMware vCenter")
ok(L.softwareOf(kevIt("VMware", "ESXi and Workstation"), allSw) === "vmware", "KEV: ESXi and Workstation")
ok(L.softwareOf(kevIt("VMware", "Spring Cloud Gateway"), allSw) === "", "KEV: VMware Spring räknas inte")
ok(L.softwareOf(kevIt("Oracle", "MySQL"), allSw) === "mysql", "KEV: Oracle MySQL")
ok(L.softwareOf(kevIt("Jenkins", "Jenkins Command Line Interface (CLI)"), allSw) === "jenkins", "KEV: Jenkins CLI")
ok(L.softwareOf(kevIt("GitLab", "GitLab CE/EE"), allSw) === "gitlab", "KEV: GitLab")
const cs = name => ({ kind: "certse", id: "C", vendor: "CERT-SE", product: "", name, desc: "", cpes: [], sw: [] })
ok(L.softwareOf(cs("Kritiska sårbarheter i VMware vCenter och ESX"), allSw) === "vmware", "CERT-SE: VMware")
ok(L.softwareOf(cs("Kritisk sårbarhet i GitLab"), allSw) === "gitlab", "CERT-SE: GitLab")
ok(L.softwareOf(cs("Kritisk sårbarhet i Proxmox VE"), allSw) === "proxmox", "CERT-SE: Proxmox")
// Bedömning: vCenter 9.8 utan KEV och utan EPSS visas som kritisk på alla nivåer när VMware är valt
const vc = recItem("CVE-2024-38812")
ok(L.evaluate(vc, "strict", "").tier === 0, "vCenter 9.8 utan KEV/EPSS visas inte utan valt program")
ok(["strict", "normal", "broad"].every(lv => L.evaluate(vc, lv, "vmware").tier === 2), "vCenter 9.8 kritisk på alla nivåer med VMware valt")
const px = recItem("CVE-2024-21545")
ok(L.evaluate(px, "broad", "proxmox").tier === 0, "Proxmox 8.2 utan KEV visas inte (under 9)")
const rs = L.assess(Object.values(rec).length ? Object.keys(rec).map(recItem) : [], "normal", [], {}, Object.assign({}, L.DEFAULT_PLATFORMS, { virt: false }), on("vmware"))
ok(rs.items.some(x => x.id === "CVE-2024-38812" && x.tier === 2), "VMware visas trots att hypervisorer är avstängda")

// Tyst tid
const late = new Date(2026, 10, 19, 23, 30).getTime()
ok(new Date(L.alarmTime(late, true, 22, 7)).getHours() === 7 && new Date(L.alarmTime(late, true, 22, 7)).getDate() === 20, "larm 23:30 flyttas till 07:00")
const early = new Date(2026, 10, 19, 5, 0).getTime()
ok(new Date(L.alarmTime(early, true, 22, 7)).getDate() === 19, "larm 05:00 flyttas till 07:00 samma dag")
ok(L.alarmTime(late, false, 22, 7) === late + 60000, "utan tyst tid: om en minut")
ok(L.alarmMessage([byId("CVE-2026-90436")]) === "PatchNow: CVE-2026-90436 – Apache Axis", "larmtext")

console.log(fails ? fails + " fel" : "alla tester gick igenom")
process.exit(fails ? 1 : 0)
