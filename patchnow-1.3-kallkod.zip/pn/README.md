# PatchNow

PatchNow för Ubuntu Touch visar bara de sårbarheter som behöver åtgärdas nu: de som utnyttjas aktivt och är kritiska. Resten sorteras bort.

## Källor
- **CISA KEV** (Known Exploited Vulnerabilities): sårbarheter som bevisat utnyttjas. Filen hämtas med ETag, så en oförändrad katalog ger bara svaret 304. Om cisa.gov inte svarar används spegeln på GitHub (`cisagov/kev-data`).
- **NVD API 2.0**: CVSS, vektor och CISA:s SSVC-bedömning. Fullständig hämtning en gång per dygn, annars bara ändringar (`lastModStartDate`). Utan API-nyckel tillåter NVD 5 anrop per 30 s, och appen gör 2 per kontroll.
- **EPSS** från FIRST: sannolikheten att en sårbarhet utnyttjas inom 30 dagar.
- **CERT-SE** (Atom-flödet `https://www.cert.se/feed.xml`): rubriker som börjar med "Kritisk sårbarhet" blir egna poster, och nämnda CVE:er får en etikett.

## Nivåer
| Nivå | Kritiskt = åtgärda nu |
|---|---|
| Strikt | KEV + CVSS ≥ 9 + nås över nätet utan inloggning och klick (AV:N/PR:N/UI:N) + CISA har inte sagt "automatable: no". Nya CVE:er utanför KEV: CVSS ≥ 9, nätet och EPSS ≥ 70 %. |
| Normal | KEV + CVSS ≥ 9 + nätet utan inloggning, eller KEV + CVSS ≥ 8 och ransomware eller CERT-SE-varning. Nya CVE:er: CVSS ≥ 9, nätet och EPSS ≥ 40 %. CERT-SE:s "Kritisk sårbarhet …". |
| Bred | KEV + CVSS ≥ 8, eller ≥ 7 över nätet utan inloggning, eller ransomware. Nya CVE:er: EPSS ≥ 20 %. |

Saknar NVD poäng än används CISA:s SSVC (automatable + total) eller beskrivningen (oautentiserad kodkörning).
Med data från oktober–november 2026 gav Strikt cirka 9 och Normal cirka 12 kritiska poster per månad.

## Plattformar
Varje sårbarhet får en plattform: `windows`, `linux`, `apps` (serverprogram på Windows/Linux), `virt` (hypervisorer), `device` (nätverksutrustning och apparater) eller `client` (datorer och mobiler). Plattformen läses i första hand från NVD:s sårbara CPE:er (`Logic.platformOf`), annars från leverantörens och produktens namn. Som standard visas windows, linux, apps och virt. Det går att ändra under Inställningar → Plattformar. Med data från okt–nov 2026 sjönk antalet kritiska (Normal) från 19 till 14, eftersom bland annat Cisco, Fortinet, Palo Alto, Ivanti Connect Secure, NetScaler, Barracuda och Synology försvann.

Leverantörer kan fortfarande döljas en och en med ett svep åt vänster.

## Program du kör
Under Inställningar → Program du kör kan man slå på PHP, Drupal, CakePHP, nginx, Java (JDK/JRE), Apache HTTP Server, VMware vSphere (ESX, vCenter, Cloud Foundation, NSX, Aria, VMware Tools), Proxmox (VE, Backup Server), MySQL/MariaDB, Jenkins (även tillägg) och GitLab. Ett valt program + (KEV, CVSS ≥ 9, oautentiserad RCE utan poäng eller CERT-SE-varning) ger kritisk på alla nivåer, även om leverantören är dold eller plattformen avstängd. Matchningen (`Logic.softwareOf`) går i första hand på CPE (och CPE:ns target_sw för tillägg), sedan KEV:s leverantör/produkt och CERT-SE-rubriken, och till sist beskrivningen när NVD inte har analyserat posten än (som ett nytt VMSA från Broadcom). VMware Spring/Tanzu/Horizon och Workstation/Fusion utan ESX räknas inte, och inte heller MySQL Connectors eller SQL-injektioner i webbappar som nämner MySQL.

## Två versioner
| Version | Larm | Behörigheter | Distribution |
|---|---|---|---|
| X.Y.0 (nu 1.3.0) | Nej, bara i appen | `networking` (*common*) | OpenStore |
| X.Y.1 (nu 1.3.1) | Engångslarm i Klocka-appen | `networking`, `calendar` (*reserved*) | GitHub Releases, eller OpenStore efter manuell granskning |

Båda byggs från samma källkod med `tools/build.sh`, som läser versionen ur `manifest.json` och sätter `.1` på larmversionen. Skillnaden är flaggan `alarmsEnabled` i `qml/Main.qml` och `calendar` i apparmor.

## Bakgrundskoll
Ubuntu Touch fryser appar som inte syns. Med **UT Tweak Tool → Applications → PatchNow → Prevent app suspension** fortsätter appen att kolla (varje timme, var 3:e eller var 6:e timme) när den ligger i bakgrunden. Larmet i 1.1.0 sätts då som ett vanligt larm, som väcker telefonen.

## Bygga och installera
```bash
tools/build.sh                        # ger build/patchnow.johanfinn_1.0.0_all.click och _1.1.0_all.click
adb push build/patchnow.johanfinn_1.0.0_all.click /home/phablet/Downloads/
adb shell gdbus call --system --dest com.lomiri.click --object-path /com/lomiri/click \
    --method com.lomiri.click.Install /home/phablet/Downloads/patchnow.johanfinn_1.0.0_all.click
```

## Testa på datorn
```bash
node tests/logic.test.js
QML_XHR_ALLOW_FILE_READ=1 GRID_UNIT_PX=16 UITK_ICON_THEME=suru qmlscene qml/Main.qml --demo --lang=sv --theme=dark
```
Flaggor: `--demo` (sparade svar från CISA, NVD och CERT-SE i en egen databas), `--lang=sv|en`, `--theme=light|dark`, `--page=settings|alert`, `--index=<n>`, `--height=<gu>`, `--level=strict|normal|broad` och `--software=a,b` (bara med `--demo`), `--simulate-new` (låtsas att den nyaste kritiska posten är ny, för att testa larmet) och `--debug`.

## Struktur
| Fil | Innehåll |
|---|---|
| `qml/Main.qml` | MainView, hämtning, cache, bedömning, larm |
| `qml/AlertListPage.qml` | Listan med sammanfattning, svep för åtgärdad/dölj leverantör |
| `qml/AlertPage.qml` | Varför det är kritiskt, fakta, CISA:s åtgärd, länkar |
| `qml/SettingsPage.qml` | Nivå, period, bakgrundskoll, larm, dolda leverantörer, tema, språk, om |
| `qml/Logic.js` | Adresser, tolkning (KEV, NVD, EPSS, Atom/RSS), bedömning, tyst tid (ren JS) |
| `qml/Storage.js` | SQLite: inställningar, cache, sedda och åtgärdade poster |
| `qml/I18n.js` | Översättningar |

## Licens
Copyright © 2026 Johan Finn. GNU General Public License v3.0 eller senare.
This product uses data from the NVD API but is not endorsed or certified by the NVD.
EPSS: FIRST.org. KEV: CISA. PatchNow har ingen koppling till någon av källorna.
