# Changelog

## 1.3.0 / 1.3.1
- More software to choose under "Software you run": VMware vSphere (ESX, vCenter, Cloud Foundation, NSX, Aria, VMware Tools), Proxmox (VE, Backup Server), MySQL/MariaDB, Jenkins (including plugins) and GitLab. Critical vulnerabilities (CVSS 9+) in them are shown at once, even before anyone exploits them. 1.3.1 also has the alarm.

## 1.2.0 / 1.2.1
- "Software you run": PHP, Drupal, CakePHP, nginx, Java and Apache HTTP Server. Critical vulnerabilities in the programs you turn on are always shown. 1.2.1 also has the alarm.

## 1.1.0
- Same as 1.0.0, plus a one-time alarm in the Clock app when a new vulnerability becomes critical (needs the calendar permission). Quiet hours 22–07 and a test alarm.

## 1.0.0
- First version: actively exploited and critical vulnerabilities from CISA KEV, NVD, EPSS and CERT-SE, three levels, platform filter (Windows, Linux, server software and hypervisors by default; network devices and desktop/mobile hidden), background check, mark as handled, hide vendors. English and Swedish, light/dark theme.
